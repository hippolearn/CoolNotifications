# gcc_riscv32工具链，源码编译使用说明


## 步骤一：

    打开Linux编译服务器终端。


## 步骤二：
    环境准备，请安装以下软件，确保工具链能正确编译
    gcc
    g++
    bison
    flex
    makeinfo
    
    可通过以下命令查看是否安装，如：
    $ gcc --version
    $ g++ --version
    $ bison --version
    $ flex --version
    $ makeinfo --version
    
    如果没有安装，推荐但不限于：
    $ sudo apt-get install gcc
    $ sudo apt-get install g++
    $ sudo apt-get install flex bison
    $ sudo apt-get install texinfo


## 步骤三：
    下载riscv-gnu-toolchain交叉编译工具链
    $ git clone --recursive https://github.com/riscv/riscv-gnu-toolchain


## 步骤四：
    打开文件夹riscv-gnu-toolchain，先删除空文件夹，以防止下载newlib，binutils，gcc时冲突
    $ cd riscv-gnu-toolchain
    $ rm -rf riscv-newlib
    $ rm -rf riscv-binutils
    $ rm -rf riscv-gcc


## 步骤五：
    下载riscv-newlib-3.0.0
    $ git clone -b riscv-newlib-3.0.0 https://github.com/riscv/riscv-newlib.git


## 步骤六：
    下载riscv-binutils-2.31.1
    $ git clone -b riscv-binutils-2.31.1 https://github.com/riscv/riscv-binutils-gdb.git


## 步骤七：
    下载riscv-gcc-7.3.0
    $ git clone -b riscv-gcc-7.3.0 https://github.com/riscv/riscv-gcc


## 步骤八：
    下载riscv-gcc-7.3.0补丁
    拷贝gcc官方89411.patch，并对应代码做一定的行数号修改：
    https://gcc.gnu.org/git/?p=gcc.git;a=patch;h=026216a753ef0a757a9e368a59fa667ea422cf09;hp=2a23a1c39fb33df0277abd4486a3da64ae5e62c2
    拷贝gcc官方86724.patch：
    https://gcc.gnu.org/git/?p=gcc.git;a=blobdiff;f=gcc/graphite.h;h=be0a22b38942850d88feb159603bb846a8607539;hp=4e0e58c60ab83f1b8acf576e83330466775fac17;hb=b1761565882ed6a171136c2c89e597bc4dd5b6bf;hpb=fbd5f023a03f9f60c6ae36133703af5a711842a3
    将两个patch放入 riscv-gcc目录
    $ cd riscv-gcc
    $ patch -p1 < 89411.patch
    $ patch -p1 < 86724.patch
    patch过程中如遇到Hunk #1 FAILED等问题，请对应到相应.c文件，修改patch代码所在行数


## 步骤九：
    下载GMP 6.1.2 ，并解压安装：https://gmplib.org/download/gmp/gmp-6.1.2.tar.bz2
    运行以下命令：
    $ tar -xvf gmp-6.1.2.tar.bz2
    $ mkdir build_gmp
    $ cd build_gmp
    $ ../gmp-6.1.2/configure --prefix=/usr/local/gmp-6.1.2 --disable-shared --enable-cxx
    $ make && make install


## 步骤十：
    下载mpfr-4.0.2 ，并解压安装：https://www.mpfr.org/mpfr-4.0.2/mpfr-4.0.2.tar.gz
    运行以下命令：
    $ tar -xvf mpfr-4.0.2.tar.gz
    $ mkdir build_mpfr
    $ cd build_mpfr
    $ ../mpfr-4.0.2/configure --prefix=/usr/local/mpfr-4.0.2 --with-gmp=/usr/local/gmp-6.1.2 --disable-shared 
    $ make && make install


## 步骤十一：
    下载mpc-1.1.0 ，并解压安装：https://ftp.gnu.org/gnu/mpc/mpc-1.1.0.tar.gz
    运行以下命令：
    $ tar -xvf mpc-1.1.0.tar.gz
    $ mkdir build_mpc
    $ cd build_mpc
    $ ../mpc-1.1.0/configure --prefix=/usr/local/mpc-1.1.0 --with-gmp=/usr/local/gmp-6.1.2 --with-mpfr=/usr/local/mpfr-4.0.2 --disable-shared
    $ make && make install


## 步骤十二：
    打开文件夹riscv-gnu-toolchain,新建工具链输出目录
    $ cd riscv-gnu-toolchain
    $ mkdir gcc-riscv32


## 步骤十三：
    编译bintutils
    $ mkdir build_binutils && cd build_binutils
    $ ../riscv-binutils-gdb/configure --prefix=/opt/gcc_riscv32 --target=riscv32-unknown-elf --with-arch=rv32imc --with-abi=ilp32 --disable-__cxa_atexit --disable-libgomp --disable-libmudflap --enable-libssp --disable-libstdcxx-pch --disable-nls --disable-shared --disable-threads --disable-multilib --enable-poison-system-directories --enable-languages=c,c++ --with-gnu-as --with-gnu-ld --with-newlib --with-system-zlib CFLAGS="-fstack-protector-strong -O2 -D_FORTIFY_SOURCE=2 -Wl,-z,relro,-z,now,-z,noexecstack -fPIE" CXXFLAGS="-fstack-protector-strong -O2 -D_FORTIFY_SOURCE=2 -Wl,-z,relro,-z,now,-z,noexecstack -fPIE" CXXFLAGS_FOR_TARGET="-Os -mcmodel=medlow -Wall -fstack-protector-strong -Wl,-z,relro,-z,now,-z,noexecstack -Wtrampolines -fno-short-enums -fno-short-wchar" CFLAGS_FOR_TARGET="-Os -mcmodel=medlow -Wall -fstack-protector-strong -Wl,-z,relro,-z,now,-z,noexecstack -Wtrampolines -fno-short-enums -fno-short-wchar" --bindir=/opt/gcc_riscv32/bin --libexecdir=/opt/gcc_riscv32/riscv32 --libdir=/opt/gcc_riscv32 --includedir=/opt/gcc_riscv32
    $ make -j16 && make install


## 步骤十四：
    编译newlib
    $ mkdir build_newlib && cd build_newlib
    $ ../riscv-newlib/configure --prefix=/opt/gcc_riscv32 --target=riscv32-unknown-elf --with-arch=rv32imc --with-abi=ilp32 --disable-__cxa_atexit --disable-libgomp --disable-libmudflap --enable-libssp --disable-libstdcxx-pch --disable-nls --disable-shared --disable-threads --disable-multilib --enable-poison-system-directories --enable-languages=c,c++ --with-gnu-as --with-gnu-ld --with-newlib --with-system-zlib CFLAGS="-fstack-protector-strong -O2 -D_FORTIFY_SOURCE=2 -Wl,-z,relro,-z,now,-z,noexecstack -fPIE" CXXFLAGS="-fstack-protector-strong -O2 -D_FORTIFY_SOURCE=2 -Wl,-z,relro,-z,now,-z,noexecstack -fPIE" \CXXFLAGS_FOR_TARGET="-Os -mcmodel=medlow -Wall -fstack-protector-strong -Wl,-z,relro,-z,now,-z,noexecstack -Wtrampolines -fno-short-enums -fno-short-wchar" CFLAGS_FOR_TARGET="-Os -mcmodel=medlow -Wall -fstack-protector-strong -Wl,-z,relro,-z,now,-z,noexecstack -Wtrampolines -fno-short-enums -fno-short-wchar" --bindir=/opt/gcc_riscv32/bin --libexecdir=/opt/gcc_riscv32 --libdir=/opt/gcc_riscv32 --includedir=/opt/gcc_riscv32
    $ make -j16 && make install


## 步骤十五：
    编译gcc
    $ mkdir build_gcc && cd build_gcc
    $ ../riscv-gcc/configure --prefix=/opt/gcc_riscv32 --target=riscv32-unknown-elf --with-arch=rv32imc --with-abi=ilp32 --disable-__cxa_atexit --disable-libgomp --disable-libmudflap --enable-libssp --disable-libstdcxx-pch --disable-nls --disable-shared --disable-threads --disable-multilib --enable-poison-system-directories --enable-languages=c,c++ --with-gnu-as --with-gnu-ld --with-newlib --with-system-zlib CFLAGS="-fstack-protector-strong -O2 -D_FORTIFY_SOURCE=2 -Wl,-z,relro,-z,now,-z,noexecstack -fPIE" CXXFLAGS="-fstack-protector-strong -O2 -D_FORTIFY_SOURCE=2 -Wl,-z,relro,-z,now,-z,noexecstack -fPIE" LDFLAGS="-Wl,-z,relro,-z,now,-z,noexecstack" CXXFLAGS_FOR_TARGET="-Os -mcmodel=medlow -Wall -fstack-protector-strong -Wl,-z,relro,-z,now,-z,noexecstack -Wtrampolines -fno-short-enums -fno-short-wchar" CFLAGS_FOR_TARGET="-Os -mcmodel=medlow -Wall -fstack-protector-strong -Wl,-z,relro,-z,now,-z,noexecstack -Wtrampolines -fno-short-enums -fno-short-wchar" --with-headers="/opt/gcc-riscv32/riscv32-unknown-elf/include" --with-mpc=/usr/local/mpc-1.1.0 --with-gmp=/usr/local/gmp-6.1.2 --with-mpfr=/usr/local/mpfr-4.0.2
    $ make -j16 && make install


## 步骤十六：
    设置环境变量“$ vim /etc/profile”，新增“$ export PATH=/opt/gcc_riscv32/bin:$PATH”。
    生效环境变量“$ source /etc/profile”。


## 步骤十七：
    Shell命令行中输入“$ riscv32-unknown-elf-gcc -v”，查看是否安装成功。
    如果能正确显示编译器版本号，表明编译器安装成功。


## 说明：
    /opt/gcc-riscv32为gcc_riscv32编译工具链的输出路径（如需自定义可以替换该路径，该节均已“/opt/gcc_riscv32”为例）；
    以“$ ”区分上述linux命令，拷贝命令时请忽略“$ ”。
