/* Generated automatically by the program `genoutput'
   from the machine description file `md'.  */

#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "backend.h"
#include "predict.h"
#include "tree.h"
#include "rtl.h"
#include "flags.h"
#include "alias.h"
#include "varasm.h"
#include "stor-layout.h"
#include "calls.h"
#include "insn-config.h"
#include "expmed.h"
#include "dojump.h"
#include "explow.h"
#include "memmodel.h"
#include "emit-rtl.h"
#include "stmt.h"
#include "expr.h"
#include "insn-codes.h"
#include "tm_p.h"
#include "regs.h"
#include "conditions.h"
#include "insn-attr.h"

#include "recog.h"

#include "diagnostic-core.h"
#include "output.h"
#include "target.h"
#include "tm-constrs.h"

static const char *
output_3 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 417 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return TARGET_64BIT ? "addw\t%0,%1,%2" : "add\t%0,%1,%2"; }
}

static const char *
output_10 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 482 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return TARGET_64BIT ? "subw\t%0,%z1,%2" : "sub\t%0,%z1,%2"; }
}

static const char *
output_15 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 529 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return TARGET_64BIT ? "mulw\t%0,%1,%2" : "mul\t%0,%1,%2"; }
}

static const char *
output_25 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 708 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return TARGET_64BIT ? "divw\t%0,%1,%2" : "div\t%0,%1,%2"; }
}

static const char *
output_26 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 708 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return TARGET_64BIT ? "divuw\t%0,%1,%2" : "divu\t%0,%1,%2"; }
}

static const char *
output_27 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 708 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return TARGET_64BIT ? "remw\t%0,%1,%2" : "rem\t%0,%1,%2"; }
}

static const char *
output_28 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 708 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return TARGET_64BIT ? "remuw\t%0,%1,%2" : "remu\t%0,%1,%2"; }
}

static const char *
output_39 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 751 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{
    return "fsqrt.s\t%0,%1";
}
}

static const char *
output_40 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 751 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{
    return "fsqrt.d\t%0,%1";
}
}

static const char * const output_80[] = {
  "#",
  "lwu\t%0,%1",
};

static const char * const output_81[] = {
  "#",
  "lhu\t%0,%1",
};

static const char * const output_82[] = {
  "#",
  "lhu\t%0,%1",
};

static const char * const output_83[] = {
  "and\t%0,%1,0xff",
  "lbu\t%0,%1",
};

static const char * const output_84[] = {
  "and\t%0,%1,0xff",
  "lbu\t%0,%1",
};

static const char * const output_85[] = {
  "and\t%0,%1,0xff",
  "lbu\t%0,%1",
};

static const char * const output_86[] = {
  "sext.w\t%0,%1",
  "lw\t%0,%1",
};

static const char * const output_87[] = {
  "#",
  "lb\t%0,%1",
};

static const char * const output_88[] = {
  "#",
  "lb\t%0,%1",
};

static const char * const output_89[] = {
  "#",
  "lb\t%0,%1",
};

static const char * const output_90[] = {
  "#",
  "lh\t%0,%1",
};

static const char * const output_91[] = {
  "#",
  "lh\t%0,%1",
};

static const char * const output_92[] = {
  "#",
  "lh\t%0,%1",
};

static const char *
output_130 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1240 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return riscv_output_move (operands[0], operands[1]); }
}

static const char *
output_131 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1250 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return riscv_output_move (operands[0], operands[1]); }
}

static const char *
output_132 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1270 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return riscv_output_move (operands[0], operands[1]); }
}

static const char *
output_133 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1295 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return riscv_output_move (operands[0], operands[1]); }
}

static const char *
output_134 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1307 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return TARGET_64BIT ? "addw\t%0,%1,%2" : "add\t%0,%1,%2"; }
}

static const char *
output_135 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1307 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return TARGET_64BIT ? "addw\t%0,%1,%2" : "add\t%0,%1,%2"; }
}

static const char *
output_138 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1336 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return riscv_output_move (operands[0], operands[1]); }
}

static const char *
output_139 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1357 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return riscv_output_move (operands[0], operands[1]); }
}

static const char *
output_140 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1367 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return riscv_output_move (operands[0], operands[1]); }
}

static const char *
output_141 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1390 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return riscv_output_move (operands[0], operands[1]); }
}

static const char *
output_142 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1400 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return riscv_output_move (operands[0], operands[1]); }
}

static const char *
output_143 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1410 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return riscv_output_move (operands[0], operands[1]); }
}

static const char *
output_146 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1464 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{
  if (GET_CODE (operands[2]) == CONST_INT)
    operands[2] = GEN_INT (INTVAL (operands[2])
			   & (GET_MODE_BITSIZE (SImode) - 1));

  return TARGET_64BIT ? "sllw\t%0,%1,%2" : "sll\t%0,%1,%2";
}
}

static const char *
output_147 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1464 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{
  if (GET_CODE (operands[2]) == CONST_INT)
    operands[2] = GEN_INT (INTVAL (operands[2])
			   & (GET_MODE_BITSIZE (SImode) - 1));

  return TARGET_64BIT ? "sraw\t%0,%1,%2" : "sra\t%0,%1,%2";
}
}

static const char *
output_148 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1464 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{
  if (GET_CODE (operands[2]) == CONST_INT)
    operands[2] = GEN_INT (INTVAL (operands[2])
			   & (GET_MODE_BITSIZE (SImode) - 1));

  return TARGET_64BIT ? "srlw\t%0,%1,%2" : "srl\t%0,%1,%2";
}
}

static const char *
output_149 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1479 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{
  if (GET_CODE (operands[2]) == CONST_INT)
    operands[2] = GEN_INT (INTVAL (operands[2])
			   & (GET_MODE_BITSIZE (DImode) - 1));

  return "sll\t%0,%1,%2";
}
}

static const char *
output_150 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1479 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{
  if (GET_CODE (operands[2]) == CONST_INT)
    operands[2] = GEN_INT (INTVAL (operands[2])
			   & (GET_MODE_BITSIZE (DImode) - 1));

  return "sra\t%0,%1,%2";
}
}

static const char *
output_151 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1479 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{
  if (GET_CODE (operands[2]) == CONST_INT)
    operands[2] = GEN_INT (INTVAL (operands[2])
			   & (GET_MODE_BITSIZE (DImode) - 1));

  return "srl\t%0,%1,%2";
}
}

static const char *
output_152 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1495 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{
  if (GET_CODE (operands[2]) == CONST_INT)
    operands[2] = GEN_INT (INTVAL (operands[2]) & 0x1f);

  return "sllw\t%0,%1,%2";
}
}

static const char *
output_153 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1495 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{
  if (GET_CODE (operands[2]) == CONST_INT)
    operands[2] = GEN_INT (INTVAL (operands[2]) & 0x1f);

  return "sraw\t%0,%1,%2";
}
}

static const char *
output_154 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1495 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{
  if (GET_CODE (operands[2]) == CONST_INT)
    operands[2] = GEN_INT (INTVAL (operands[2]) & 0x1f);

  return "srlw\t%0,%1,%2";
}
}

static const char *
output_199 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1736 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{
  operands[2] = GEN_INT (INTVAL (operands[2]) + 1);
  return "slt\t%0,%1,%2";
}
}

static const char *
output_200 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1736 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{
  operands[2] = GEN_INT (INTVAL (operands[2]) + 1);
  return "sltu\t%0,%1,%2";
}
}

static const char *
output_201 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1736 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{
  operands[2] = GEN_INT (INTVAL (operands[2]) + 1);
  return "slt\t%0,%1,%2";
}
}

static const char *
output_202 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1736 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{
  operands[2] = GEN_INT (INTVAL (operands[2]) + 1);
  return "sltu\t%0,%1,%2";
}
}

static const char *
output_203 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1736 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{
  operands[2] = GEN_INT (INTVAL (operands[2]) + 1);
  return "slt\t%0,%1,%2";
}
}

static const char *
output_204 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 1736 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{
  operands[2] = GEN_INT (INTVAL (operands[2]) + 1);
  return "sltu\t%0,%1,%2";
}
}

static const char * const output_215[] = {
  "jr\t%0",
  "tail\t%0",
  "tail\t%0@plt",
};

static const char * const output_216[] = {
  "jr\t%1",
  "tail\t%1",
  "tail\t%1@plt",
};

static const char * const output_217[] = {
  "jalr\t%0",
  "call\t%0",
  "call\t%0@plt",
};

static const char * const output_218[] = {
  "jalr\t%1",
  "call\t%1",
  "call\t%1@plt",
};

static const char *
output_221 (rtx *operands ATTRIBUTE_UNUSED, rtx_insn *insn ATTRIBUTE_UNUSED)
{
#line 2050 "../../riscv-gcc/gcc/config/riscv/riscv.md"
{ return riscv_output_gpr_save (INTVAL (operands[0])); }
}



static const struct insn_operand_data operand_data[] = 
{
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    0,
    0
  },
  {
    register_operand,
    "=f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r,r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r,r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    arith_operand,
    "r,I",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r,r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r,r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    arith_operand,
    "r,I",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r,r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r,r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    arith_operand,
    "r,I",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r,r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "%r,r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    arith_operand,
    "r,I",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r,r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "%r,r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    arith_operand,
    "r,I",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r,r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    nonimmediate_operand,
    "r,m",
    SImode,
    0,
    0,
    1,
    1
  },
  {
    register_operand,
    "=r,r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    nonimmediate_operand,
    "r,m",
    HImode,
    0,
    0,
    1,
    1
  },
  {
    register_operand,
    "=r,r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    nonimmediate_operand,
    "r,m",
    HImode,
    0,
    0,
    1,
    1
  },
  {
    register_operand,
    "=r,r",
    HImode,
    0,
    0,
    1,
    0
  },
  {
    nonimmediate_operand,
    "r,m",
    QImode,
    0,
    0,
    1,
    1
  },
  {
    register_operand,
    "=r,r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    nonimmediate_operand,
    "r,m",
    QImode,
    0,
    0,
    1,
    1
  },
  {
    register_operand,
    "=r,r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    nonimmediate_operand,
    "r,m",
    QImode,
    0,
    0,
    1,
    1
  },
  {
    register_operand,
    "=r,r",
    HImode,
    0,
    0,
    1,
    0
  },
  {
    nonimmediate_operand,
    "r,m",
    HImode,
    0,
    0,
    1,
    1
  },
  {
    register_operand,
    "=f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    symbolic_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    symbolic_operand,
    "",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    symbolic_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    symbolic_operand,
    "",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    symbolic_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    symbolic_operand,
    "",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    symbolic_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    symbolic_operand,
    "",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    nonimmediate_operand,
    "=r,r,r,m,*f,*f,*r,*f,*m",
    DImode,
    0,
    0,
    1,
    1
  },
  {
    move_operand,
    "r,i,m,r,*J*r,*m,*f,*f,*f",
    DImode,
    0,
    0,
    1,
    1
  },
  {
    nonimmediate_operand,
    "=r,r,r,m,*f,*f,*r,*f,*m",
    DImode,
    0,
    0,
    1,
    1
  },
  {
    move_operand,
    "r,T,m,rJ,*r*J,*m,*f,*f,*f",
    DImode,
    0,
    0,
    1,
    1
  },
  {
    nonimmediate_operand,
    "=r,r,r,m,*f,*f,*r,*m",
    SImode,
    0,
    0,
    1,
    1
  },
  {
    move_operand,
    "r,T,m,rJ,*r*J,*m,*f,*f",
    SImode,
    0,
    0,
    1,
    1
  },
  {
    nonimmediate_operand,
    "=r,r,r,m,*f,*r",
    HImode,
    0,
    0,
    1,
    1
  },
  {
    move_operand,
    "r,T,m,rJ,*r*J,*f",
    HImode,
    0,
    0,
    1,
    1
  },
  {
    register_operand,
    "=r,r",
    HImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r,r",
    HImode,
    0,
    0,
    1,
    0
  },
  {
    arith_operand,
    "r,I",
    HImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r,r",
    HImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r,r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    arith_operand,
    "r,I",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    nonimmediate_operand,
    "=r,r,r,m,*f,*r",
    QImode,
    0,
    0,
    1,
    1
  },
  {
    move_operand,
    "r,I,m,rJ,*r*J,*f",
    QImode,
    0,
    0,
    1,
    1
  },
  {
    nonimmediate_operand,
    "=f,f,f,m,m,*f,*r,*r,*r,*m",
    SFmode,
    0,
    0,
    1,
    1
  },
  {
    move_operand,
    "f,G,m,f,G,*r,*f,*G*r,*m,*r",
    SFmode,
    0,
    0,
    1,
    1
  },
  {
    nonimmediate_operand,
    "=r,r,m",
    SFmode,
    0,
    0,
    1,
    1
  },
  {
    move_operand,
    "Gr,m,r",
    SFmode,
    0,
    0,
    1,
    1
  },
  {
    nonimmediate_operand,
    "=f,f,f,m,m,*r,*r,*m",
    DFmode,
    0,
    0,
    1,
    1
  },
  {
    move_operand,
    "f,G,m,f,G,*r*G,*m,*r",
    DFmode,
    0,
    0,
    1,
    1
  },
  {
    nonimmediate_operand,
    "=f,f,f,m,m,*f,*r,*r,*r,*m",
    DFmode,
    0,
    0,
    1,
    1
  },
  {
    move_operand,
    "f,G,m,f,G,*r,*f,*r*G,*m,*r",
    DFmode,
    0,
    0,
    1,
    1
  },
  {
    nonimmediate_operand,
    "=r,r,m",
    DFmode,
    0,
    0,
    1,
    1
  },
  {
    move_operand,
    "rG,m,rG",
    DFmode,
    0,
    0,
    1,
    1
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    arith_operand,
    "rI",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    arith_operand,
    "rI",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    arith_operand,
    "rI",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    order_operator,
    "",
    VOIDmode,
    0,
    1,
    0,
    0
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    order_operator,
    "",
    VOIDmode,
    0,
    1,
    0,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    signed_order_operator,
    "",
    VOIDmode,
    0,
    1,
    0,
    0
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    signed_order_operator,
    "",
    VOIDmode,
    0,
    1,
    0,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    equality_operator,
    "",
    VOIDmode,
    0,
    1,
    0,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    branch_on_bit_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=&r",
    SImode,
    0,
    0,
    0,
    0
  },
  {
    equality_operator,
    "",
    VOIDmode,
    0,
    1,
    0,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    branch_on_bit_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=&r",
    DImode,
    0,
    0,
    0,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    fp_native_comparison,
    "",
    SImode,
    0,
    1,
    0,
    0
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    fp_native_comparison,
    "",
    DImode,
    0,
    1,
    0,
    0
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    fp_native_comparison,
    "",
    SImode,
    0,
    1,
    0,
    0
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    fp_native_comparison,
    "",
    DImode,
    0,
    1,
    0,
    0
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=&r",
    SImode,
    0,
    0,
    0,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=&r",
    DImode,
    0,
    0,
    0,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=&r",
    SImode,
    0,
    0,
    0,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=&r",
    DImode,
    0,
    0,
    0,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    arith_operand,
    "rI",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    sle_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    sle_operand,
    "",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    sle_operand,
    "",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "l",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "l",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "l",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "l",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    pmode_register_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=&r",
    SImode,
    0,
    0,
    0,
    0
  },
  {
    register_operand,
    "r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=&r",
    DImode,
    0,
    0,
    0,
    0
  },
  {
    call_insn_operand,
    "j,S,U",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    call_insn_operand,
    "j,S,U",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    call_insn_operand,
    "l,S,U",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    csr_operand,
    "rK",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    BLKmode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    memory_operand,
    "=A",
    SImode,
    0,
    0,
    1,
    1
  },
  {
    reg_or_0_operand,
    "rJ",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    memory_operand,
    "=A",
    DImode,
    0,
    0,
    1,
    1
  },
  {
    reg_or_0_operand,
    "rJ",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    memory_operand,
    "+A",
    SImode,
    0,
    0,
    1,
    1
  },
  {
    reg_or_0_operand,
    "rJ",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    memory_operand,
    "+A",
    DImode,
    0,
    0,
    1,
    1
  },
  {
    reg_or_0_operand,
    "rJ",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=&r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    memory_operand,
    "+A",
    SImode,
    0,
    0,
    1,
    1
  },
  {
    reg_or_0_operand,
    "rJ",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=&r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    memory_operand,
    "+A",
    DImode,
    0,
    0,
    1,
    1
  },
  {
    reg_or_0_operand,
    "rJ",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=&r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    memory_operand,
    "+A",
    SImode,
    0,
    0,
    1,
    1
  },
  {
    register_operand,
    "0",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=&r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    memory_operand,
    "+A",
    DImode,
    0,
    0,
    1,
    1
  },
  {
    register_operand,
    "0",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=&r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    memory_operand,
    "+A",
    SImode,
    0,
    0,
    1,
    1
  },
  {
    reg_or_0_operand,
    "rJ",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=&r",
    SImode,
    0,
    0,
    0,
    0
  },
  {
    register_operand,
    "=&r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    memory_operand,
    "+A",
    DImode,
    0,
    0,
    1,
    1
  },
  {
    reg_or_0_operand,
    "rJ",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=&r",
    DImode,
    0,
    0,
    0,
    0
  },
  {
    register_operand,
    "=r",
    QImode,
    0,
    0,
    1,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    HImode,
    0,
    0,
    1,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=r",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "=f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=r",
    DImode,
    0,
    0,
    0,
    0
  },
  {
    register_operand,
    "=f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=r",
    DImode,
    0,
    0,
    0,
    0
  },
  {
    register_operand,
    "=f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=r",
    SImode,
    0,
    0,
    0,
    0
  },
  {
    register_operand,
    "=f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=r",
    SImode,
    0,
    0,
    0,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    QImode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=&r",
    DImode,
    0,
    0,
    0,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    HImode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=&r",
    DImode,
    0,
    0,
    0,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=&r",
    DImode,
    0,
    0,
    0,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=&r",
    DImode,
    0,
    0,
    0,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    QImode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=&r",
    SImode,
    0,
    0,
    0,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    HImode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=&r",
    SImode,
    0,
    0,
    0,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=&r",
    SImode,
    0,
    0,
    0,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "rJ",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=&r",
    SImode,
    0,
    0,
    0,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=r",
    DImode,
    0,
    0,
    0,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=r",
    DImode,
    0,
    0,
    0,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=r",
    SImode,
    0,
    0,
    0,
    0
  },
  {
    absolute_symbolic_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "f",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    scratch_operand,
    "=r",
    SImode,
    0,
    0,
    0,
    0
  },
  {
    register_operand,
    "",
    TImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    HImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    HImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    QImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    QImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    pmode_register_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    pmode_register_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    comparison_operator,
    "",
    VOIDmode,
    0,
    1,
    0,
    0
  },
  {
    register_operand,
    "",
    QImode,
    0,
    0,
    1,
    0
  },
  {
    nonmemory_operand,
    "",
    QImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    comparison_operator,
    "",
    VOIDmode,
    0,
    1,
    0,
    0
  },
  {
    register_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    nonmemory_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    comparison_operator,
    "",
    VOIDmode,
    0,
    1,
    0,
    0
  },
  {
    register_operand,
    "",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    nonmemory_operand,
    "",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    fp_branch_comparison,
    "",
    VOIDmode,
    0,
    1,
    0,
    0
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    fp_branch_comparison,
    "",
    VOIDmode,
    0,
    1,
    0,
    0
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    order_operator,
    "",
    SImode,
    0,
    1,
    0,
    0
  },
  {
    register_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    nonmemory_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    order_operator,
    "",
    SImode,
    0,
    1,
    0,
    0
  },
  {
    register_operand,
    "",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    nonmemory_operand,
    "",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    fp_scc_comparison,
    "",
    SImode,
    0,
    1,
    0,
    0
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "",
    SFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    fp_scc_comparison,
    "",
    SImode,
    0,
    1,
    0,
    0
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "",
    DFmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    general_operand,
    "",
    VOIDmode,
    0,
    0,
    1,
    1
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    0,
    "",
    VOIDmode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    memory_operand,
    "",
    SImode,
    0,
    0,
    1,
    1
  },
  {
    reg_or_0_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    memory_operand,
    "",
    DImode,
    0,
    0,
    1,
    1
  },
  {
    reg_or_0_operand,
    "",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    reg_or_0_operand,
    "",
    DImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
  {
    register_operand,
    "",
    QImode,
    0,
    0,
    1,
    0
  },
  {
    memory_operand,
    "+A",
    QImode,
    0,
    0,
    1,
    1
  },
  {
    const_int_operand,
    "",
    SImode,
    0,
    0,
    1,
    0
  },
};


#if GCC_VERSION >= 2007
__extension__
#endif

const struct insn_data_d insn_data[] = 
{
  /* <internal>:0 */
  {
    "*placeholder_for_nothing",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { 0 },
    &operand_data[0],
    0,
    0,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:403 */
  {
    "addsf3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fadd.s\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_addsf3 },
    &operand_data[1],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:403 */
  {
    "adddf3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fadd.d\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_adddf3 },
    &operand_data[4],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:412 */
  {
    "addsi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_3 },
#else
    { 0, 0, output_3 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_addsi3 },
    &operand_data[7],
    3,
    3,
    0,
    2,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:421 */
  {
    "adddi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "add\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_adddi3 },
    &operand_data[10],
    3,
    3,
    0,
    2,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:430 */
  {
    "*addsi3_extended",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "addw\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[13],
    3,
    3,
    0,
    2,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:440 */
  {
    "*addsi3_extended2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "addw\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[10],
    3,
    3,
    0,
    2,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:459 */
  {
    "subsf3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fsub.s\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_subsf3 },
    &operand_data[1],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:459 */
  {
    "subdf3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fsub.d\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_subdf3 },
    &operand_data[4],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:468 */
  {
    "subdi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sub\t%0,%z1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_subdi3 },
    &operand_data[16],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:477 */
  {
    "subsi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_10 },
#else
    { 0, 0, output_10 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_subsi3 },
    &operand_data[19],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:486 */
  {
    "*subsi3_extended",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "subw\t%0,%z1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[22],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:496 */
  {
    "*subsi3_extended2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "subw\t%0,%z1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[25],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:515 */
  {
    "mulsf3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fmul.s\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_mulsf3 },
    &operand_data[1],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:515 */
  {
    "muldf3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fmul.d\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_muldf3 },
    &operand_data[4],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:524 */
  {
    "mulsi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_15 },
#else
    { 0, 0, output_15 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_mulsi3 },
    &operand_data[28],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:533 */
  {
    "muldi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "mul\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_muldi3 },
    &operand_data[31],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:542 */
  {
    "*mulsi3_extended",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "mulw\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[34],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:552 */
  {
    "*mulsi3_extended2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "mulw\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[31],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:589 */
  {
    "muldi3_highpart",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "mulh\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_muldi3_highpart },
    &operand_data[31],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:589 */
  {
    "umuldi3_highpart",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "mulhu\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_umuldi3_highpart },
    &operand_data[31],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:620 */
  {
    "usmuldi3_highpart",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "mulhsu\t%0,%2,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_usmuldi3_highpart },
    &operand_data[31],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:650 */
  {
    "mulsi3_highpart",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "mulh\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_mulsi3_highpart },
    &operand_data[28],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:650 */
  {
    "umulsi3_highpart",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "mulhu\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_umulsi3_highpart },
    &operand_data[28],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:681 */
  {
    "usmulsi3_highpart",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "mulhsu\t%0,%2,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_usmulsi3_highpart },
    &operand_data[28],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:703 */
  {
    "divsi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_25 },
#else
    { 0, 0, output_25 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_divsi3 },
    &operand_data[28],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:703 */
  {
    "udivsi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_26 },
#else
    { 0, 0, output_26 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_udivsi3 },
    &operand_data[28],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:703 */
  {
    "modsi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_27 },
#else
    { 0, 0, output_27 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_modsi3 },
    &operand_data[28],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:703 */
  {
    "umodsi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_28 },
#else
    { 0, 0, output_28 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_umodsi3 },
    &operand_data[28],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:712 */
  {
    "divdi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "div\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_divdi3 },
    &operand_data[31],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:712 */
  {
    "udivdi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "divu\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_udivdi3 },
    &operand_data[31],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:712 */
  {
    "moddi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "rem\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_moddi3 },
    &operand_data[31],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:712 */
  {
    "umoddi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "remu\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_umoddi3 },
    &operand_data[31],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:721 */
  {
    "*divsi3_extended",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "divw\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[34],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:721 */
  {
    "*udivsi3_extended",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "divuw\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[34],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:721 */
  {
    "*modsi3_extended",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "remw\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[34],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:721 */
  {
    "*umodsi3_extended",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "remuw\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[34],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:731 */
  {
    "divsf3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fdiv.s\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_divsf3 },
    &operand_data[1],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:731 */
  {
    "divdf3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fdiv.d\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_divdf3 },
    &operand_data[4],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:747 */
  {
    "sqrtsf2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_39 },
#else
    { 0, 0, output_39 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_sqrtsf2 },
    &operand_data[1],
    2,
    2,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:747 */
  {
    "sqrtdf2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_40 },
#else
    { 0, 0, output_40 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_sqrtdf2 },
    &operand_data[4],
    2,
    2,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:760 */
  {
    "fmasf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fmadd.s\t%0,%1,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fmasf4 },
    &operand_data[37],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:760 */
  {
    "fmadf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fmadd.d\t%0,%1,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fmadf4 },
    &operand_data[41],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:772 */
  {
    "fmssf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fmsub.s\t%0,%1,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fmssf4 },
    &operand_data[37],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:772 */
  {
    "fmsdf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fmsub.d\t%0,%1,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fmsdf4 },
    &operand_data[41],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:784 */
  {
    "fnmssf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fnmadd.s\t%0,%1,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fnmssf4 },
    &operand_data[37],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:784 */
  {
    "fnmsdf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fnmadd.d\t%0,%1,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fnmsdf4 },
    &operand_data[41],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:796 */
  {
    "fnmasf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fnmsub.s\t%0,%1,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fnmasf4 },
    &operand_data[37],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:796 */
  {
    "fnmadf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fnmsub.d\t%0,%1,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fnmadf4 },
    &operand_data[41],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:808 */
  {
    "*fmasf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fmadd.s\t%0,%1,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[37],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:808 */
  {
    "*fmadf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fmadd.d\t%0,%1,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[41],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:821 */
  {
    "*fmssf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fmsub.s\t%0,%1,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[37],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:821 */
  {
    "*fmsdf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fmsub.d\t%0,%1,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[41],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:834 */
  {
    "*fnmssf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fnmadd.s\t%0,%1,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[37],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:834 */
  {
    "*fnmsdf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fnmadd.d\t%0,%1,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[41],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:847 */
  {
    "*fnmasf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fnmsub.s\t%0,%1,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[37],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:847 */
  {
    "*fnmadf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fnmsub.d\t%0,%1,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[41],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:866 */
  {
    "abssf2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fabs.s\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_abssf2 },
    &operand_data[1],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:866 */
  {
    "absdf2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fabs.d\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_absdf2 },
    &operand_data[4],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:874 */
  {
    "copysignsf3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fsgnj.s\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_copysignsf3 },
    &operand_data[1],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:874 */
  {
    "copysigndf3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fsgnj.d\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_copysigndf3 },
    &operand_data[4],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:884 */
  {
    "negsf2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fneg.s\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_negsf2 },
    &operand_data[1],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:884 */
  {
    "negdf2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fneg.d\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_negdf2 },
    &operand_data[4],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:899 */
  {
    "sminsf3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fmin.s\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_sminsf3 },
    &operand_data[1],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:899 */
  {
    "smindf3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fmin.d\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_smindf3 },
    &operand_data[4],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:908 */
  {
    "smaxsf3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fmax.s\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_smaxsf3 },
    &operand_data[1],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:908 */
  {
    "smaxdf3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fmax.d\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_smaxdf3 },
    &operand_data[4],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:928 */
  {
    "andsi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "and\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_andsi3 },
    &operand_data[45],
    3,
    3,
    0,
    2,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:928 */
  {
    "iorsi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "or\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_iorsi3 },
    &operand_data[45],
    3,
    3,
    0,
    2,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:928 */
  {
    "xorsi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "xor\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_xorsi3 },
    &operand_data[45],
    3,
    3,
    0,
    2,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:928 */
  {
    "anddi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "and\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_anddi3 },
    &operand_data[48],
    3,
    3,
    0,
    2,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:928 */
  {
    "iordi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "or\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_iordi3 },
    &operand_data[48],
    3,
    3,
    0,
    2,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:928 */
  {
    "xordi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "xor\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_xordi3 },
    &operand_data[48],
    3,
    3,
    0,
    2,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:937 */
  {
    "*andsi3_internal",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "and\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[45],
    3,
    3,
    0,
    2,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:937 */
  {
    "*iorsi3_internal",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "or\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[45],
    3,
    3,
    0,
    2,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:937 */
  {
    "*xorsi3_internal",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "xor\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[45],
    3,
    3,
    0,
    2,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:946 */
  {
    "one_cmplsi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "not\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_one_cmplsi2 },
    &operand_data[28],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:946 */
  {
    "one_cmpldi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "not\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_one_cmpldi2 },
    &operand_data[31],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:954 */
  {
    "*one_cmplsi2_internal",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "not\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[28],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:969 */
  {
    "truncdfsf2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.s.d\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_truncdfsf2 },
    &operand_data[51],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:986 */
  {
    "zero_extendsidi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .multi = output_80 },
#else
    { 0, output_80, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_zero_extendsidi2 },
    &operand_data[53],
    2,
    2,
    0,
    2,
    2
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1002 */
  {
    "zero_extendhisi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .multi = output_81 },
#else
    { 0, output_81, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_zero_extendhisi2 },
    &operand_data[55],
    2,
    2,
    0,
    2,
    2
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1002 */
  {
    "zero_extendhidi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .multi = output_82 },
#else
    { 0, output_82, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_zero_extendhidi2 },
    &operand_data[57],
    2,
    2,
    0,
    2,
    2
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1021 */
  {
    "zero_extendqihi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .multi = output_83 },
#else
    { 0, output_83, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_zero_extendqihi2 },
    &operand_data[59],
    2,
    2,
    0,
    2,
    2
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1021 */
  {
    "zero_extendqisi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .multi = output_84 },
#else
    { 0, output_84, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_zero_extendqisi2 },
    &operand_data[61],
    2,
    2,
    0,
    2,
    2
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1021 */
  {
    "zero_extendqidi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .multi = output_85 },
#else
    { 0, output_85, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_zero_extendqidi2 },
    &operand_data[63],
    2,
    2,
    0,
    2,
    2
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1039 */
  {
    "extendsidi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .multi = output_86 },
#else
    { 0, output_86, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_extendsidi2 },
    &operand_data[53],
    2,
    2,
    0,
    2,
    2
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1049 */
  {
    "extendqihi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .multi = output_87 },
#else
    { 0, output_87, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_extendqihi2 },
    &operand_data[59],
    2,
    2,
    0,
    2,
    2
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1049 */
  {
    "extendqisi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .multi = output_88 },
#else
    { 0, output_88, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_extendqisi2 },
    &operand_data[61],
    2,
    2,
    0,
    2,
    2
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1049 */
  {
    "extendqidi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .multi = output_89 },
#else
    { 0, output_89, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_extendqidi2 },
    &operand_data[63],
    2,
    2,
    0,
    2,
    2
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1049 */
  {
    "extendhihi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .multi = output_90 },
#else
    { 0, output_90, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_extendhihi2 },
    &operand_data[65],
    2,
    2,
    0,
    2,
    2
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1049 */
  {
    "extendhisi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .multi = output_91 },
#else
    { 0, output_91, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_extendhisi2 },
    &operand_data[55],
    2,
    2,
    0,
    2,
    2
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1049 */
  {
    "extendhidi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .multi = output_92 },
#else
    { 0, output_92, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_extendhidi2 },
    &operand_data[57],
    2,
    2,
    0,
    2,
    2
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1069 */
  {
    "extendsfdf2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.d.s\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_extendsfdf2 },
    &operand_data[67],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1084 */
  {
    "fix_truncsfsi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.w.s %0,%1,rtz",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fix_truncsfsi2 },
    &operand_data[69],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1084 */
  {
    "fix_truncsfdi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.l.s %0,%1,rtz",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fix_truncsfdi2 },
    &operand_data[71],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1084 */
  {
    "fix_truncdfsi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.w.d %0,%1,rtz",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fix_truncdfsi2 },
    &operand_data[73],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1084 */
  {
    "fix_truncdfdi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.l.d %0,%1,rtz",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fix_truncdfdi2 },
    &operand_data[75],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1092 */
  {
    "fixuns_truncsfsi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.wu.s %0,%1,rtz",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fixuns_truncsfsi2 },
    &operand_data[69],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1092 */
  {
    "fixuns_truncsfdi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.lu.s %0,%1,rtz",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fixuns_truncsfdi2 },
    &operand_data[71],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1092 */
  {
    "fixuns_truncdfsi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.wu.d %0,%1,rtz",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fixuns_truncdfsi2 },
    &operand_data[73],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1092 */
  {
    "fixuns_truncdfdi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.lu.d %0,%1,rtz",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fixuns_truncdfdi2 },
    &operand_data[75],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1100 */
  {
    "floatsisf2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.s.w\t%0,%z1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_floatsisf2 },
    &operand_data[77],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1100 */
  {
    "floatdisf2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.s.l\t%0,%z1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_floatdisf2 },
    &operand_data[79],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1100 */
  {
    "floatsidf2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.d.w\t%0,%z1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_floatsidf2 },
    &operand_data[81],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1100 */
  {
    "floatdidf2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.d.l\t%0,%z1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_floatdidf2 },
    &operand_data[83],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1108 */
  {
    "floatunssisf2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.s.wu\t%0,%z1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_floatunssisf2 },
    &operand_data[77],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1108 */
  {
    "floatunsdisf2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.s.lu\t%0,%z1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_floatunsdisf2 },
    &operand_data[79],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1108 */
  {
    "floatunssidf2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.d.wu\t%0,%z1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_floatunssidf2 },
    &operand_data[81],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1108 */
  {
    "floatunsdidf2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.d.lu\t%0,%z1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_floatunsdidf2 },
    &operand_data[83],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1116 */
  {
    "lrintsfsi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.w.s %0,%1,dyn",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_lrintsfsi2 },
    &operand_data[69],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1116 */
  {
    "lroundsfsi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.w.s %0,%1,rmm",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_lroundsfsi2 },
    &operand_data[69],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1116 */
  {
    "lrintsfdi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.l.s %0,%1,dyn",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_lrintsfdi2 },
    &operand_data[71],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1116 */
  {
    "lroundsfdi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.l.s %0,%1,rmm",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_lroundsfdi2 },
    &operand_data[71],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1116 */
  {
    "lrintdfsi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.w.d %0,%1,dyn",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_lrintdfsi2 },
    &operand_data[73],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1116 */
  {
    "lrounddfsi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.w.d %0,%1,rmm",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_lrounddfsi2 },
    &operand_data[73],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1116 */
  {
    "lrintdfdi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.l.d %0,%1,dyn",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_lrintdfdi2 },
    &operand_data[75],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1116 */
  {
    "lrounddfdi2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fcvt.l.d %0,%1,rmm",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_lrounddfdi2 },
    &operand_data[75],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1136 */
  {
    "got_loadsi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "la\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_got_loadsi },
    &operand_data[85],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1136 */
  {
    "got_loaddi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "la\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_got_loaddi },
    &operand_data[87],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1145 */
  {
    "tls_add_tp_lesi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "add\t%0,%1,%2,%%tprel_add(%3)",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_tls_add_tp_lesi },
    &operand_data[89],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1145 */
  {
    "tls_add_tp_ledi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "add\t%0,%1,%2,%%tprel_add(%3)",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_tls_add_tp_ledi },
    &operand_data[93],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1156 */
  {
    "got_load_tls_gdsi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "la.tls.gd\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_got_load_tls_gdsi },
    &operand_data[85],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1156 */
  {
    "got_load_tls_gddi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "la.tls.gd\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_got_load_tls_gddi },
    &operand_data[87],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1165 */
  {
    "got_load_tls_iesi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "la.tls.ie\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_got_load_tls_iesi },
    &operand_data[85],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1165 */
  {
    "got_load_tls_iedi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "la.tls.ie\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_got_load_tls_iedi },
    &operand_data[87],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1174 */
  {
    "auipcsi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    ".LA%2: auipc\t%0,%h1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_auipcsi },
    &operand_data[97],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1174 */
  {
    "auipcdi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    ".LA%2: auipc\t%0,%h1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_auipcdi },
    &operand_data[100],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1189 */
  {
    "*lowsi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "addi\t%0,%1,%R2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[103],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1189 */
  {
    "*lowdi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "addi\t%0,%1,%R2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[106],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1234 */
  {
    "*movdi_32bit",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_130 },
#else
    { 0, 0, output_130 },
#endif
    { 0 },
    &operand_data[109],
    2,
    2,
    0,
    9,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1244 */
  {
    "*movdi_64bit",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_131 },
#else
    { 0, 0, output_131 },
#endif
    { 0 },
    &operand_data[111],
    2,
    2,
    0,
    9,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1265 */
  {
    "*movsi_internal",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_132 },
#else
    { 0, 0, output_132 },
#endif
    { 0 },
    &operand_data[113],
    2,
    2,
    0,
    8,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1290 */
  {
    "*movhi_internal",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_133 },
#else
    { 0, 0, output_133 },
#endif
    { 0 },
    &operand_data[115],
    2,
    2,
    0,
    6,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1302 */
  {
    "*addhihi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_134 },
#else
    { 0, 0, output_134 },
#endif
    { 0 },
    &operand_data[117],
    3,
    3,
    0,
    2,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1302 */
  {
    "*addsihi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_135 },
#else
    { 0, 0, output_135 },
#endif
    { 0 },
    &operand_data[120],
    3,
    3,
    0,
    2,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1311 */
  {
    "*xorhihi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "xor\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[117],
    3,
    3,
    0,
    2,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1311 */
  {
    "*xorsihi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "xor\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[120],
    3,
    3,
    0,
    2,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1331 */
  {
    "*movqi_internal",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_138 },
#else
    { 0, 0, output_138 },
#endif
    { 0 },
    &operand_data[123],
    2,
    2,
    0,
    6,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1351 */
  {
    "*movsf_hardfloat",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_139 },
#else
    { 0, 0, output_139 },
#endif
    { 0 },
    &operand_data[125],
    2,
    2,
    0,
    10,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1361 */
  {
    "*movsf_softfloat",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_140 },
#else
    { 0, 0, output_140 },
#endif
    { 0 },
    &operand_data[127],
    2,
    2,
    0,
    3,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1384 */
  {
    "*movdf_hardfloat_rv32",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_141 },
#else
    { 0, 0, output_141 },
#endif
    { 0 },
    &operand_data[129],
    2,
    2,
    0,
    8,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1394 */
  {
    "*movdf_hardfloat_rv64",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_142 },
#else
    { 0, 0, output_142 },
#endif
    { 0 },
    &operand_data[131],
    2,
    2,
    0,
    10,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1404 */
  {
    "*movdf_softfloat",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_143 },
#else
    { 0, 0, output_143 },
#endif
    { 0 },
    &operand_data[133],
    2,
    2,
    0,
    3,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1442 */
  {
    "fence",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%|fence%-",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fence },
    &operand_data[0],
    0,
    0,
    0,
    0,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1447 */
  {
    "fence_i",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fence.i",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fence_i },
    &operand_data[0],
    0,
    0,
    0,
    0,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1459 */
  {
    "ashlsi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_146 },
#else
    { 0, 0, output_146 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_ashlsi3 },
    &operand_data[135],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1459 */
  {
    "ashrsi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_147 },
#else
    { 0, 0, output_147 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_ashrsi3 },
    &operand_data[135],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1459 */
  {
    "lshrsi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_148 },
#else
    { 0, 0, output_148 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_lshrsi3 },
    &operand_data[135],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1474 */
  {
    "ashldi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_149 },
#else
    { 0, 0, output_149 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_ashldi3 },
    &operand_data[138],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1474 */
  {
    "ashrdi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_150 },
#else
    { 0, 0, output_150 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_ashrdi3 },
    &operand_data[138],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1474 */
  {
    "lshrdi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_151 },
#else
    { 0, 0, output_151 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_lshrdi3 },
    &operand_data[138],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1489 */
  {
    "*ashlsi3_extend",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_152 },
#else
    { 0, 0, output_152 },
#endif
    { 0 },
    &operand_data[141],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1489 */
  {
    "*ashrsi3_extend",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_153 },
#else
    { 0, 0, output_153 },
#endif
    { 0 },
    &operand_data[141],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1489 */
  {
    "*lshrsi3_extend",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_154 },
#else
    { 0, 0, output_154 },
#endif
    { 0 },
    &operand_data[141],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1513 */
  {
    "*branch_ordersi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "b%C1\t%2,%3,%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[144],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1513 */
  {
    "*branch_orderdi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "b%C1\t%2,%3,%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[148],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1526 */
  {
    "*branch_zerosi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "b%C1z\t%2,%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[152],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1526 */
  {
    "*branch_zerodi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "b%C1z\t%2,%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[155],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1574 */
  {
    "*branch_on_bitsi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "#",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[158],
    4,
    5,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1574 */
  {
    "*branch_on_bitdi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "#",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[163],
    4,
    5,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1605 */
  {
    "*branch_on_bit_rangesi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "#",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[158],
    4,
    5,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1605 */
  {
    "*branch_on_bit_rangedi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "#",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[163],
    4,
    5,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1663 */
  {
    "*cstoresfsi4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "f%C1.s\t%0,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[168],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1663 */
  {
    "*cstoresfdi4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "f%C1.s\t%0,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[172],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1663 */
  {
    "*cstoredfsi4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "f%C1.d\t%0,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[176],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1663 */
  {
    "*cstoredfdi4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "f%C1.d\t%0,%2,%3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[180],
    4,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1673 */
  {
    "flt_quietsfsi4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "frflags\t%3\n\tflt.s\t%0,%1,%2\n\tfsflags %3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_flt_quietsfsi4 },
    &operand_data[184],
    3,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1673 */
  {
    "fle_quietsfsi4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "frflags\t%3\n\tfle.s\t%0,%1,%2\n\tfsflags %3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fle_quietsfsi4 },
    &operand_data[184],
    3,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1673 */
  {
    "flt_quietsfdi4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "frflags\t%3\n\tflt.s\t%0,%1,%2\n\tfsflags %3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_flt_quietsfdi4 },
    &operand_data[188],
    3,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1673 */
  {
    "fle_quietsfdi4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "frflags\t%3\n\tfle.s\t%0,%1,%2\n\tfsflags %3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fle_quietsfdi4 },
    &operand_data[188],
    3,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1673 */
  {
    "flt_quietdfsi4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "frflags\t%3\n\tflt.d\t%0,%1,%2\n\tfsflags %3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_flt_quietdfsi4 },
    &operand_data[192],
    3,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1673 */
  {
    "fle_quietdfsi4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "frflags\t%3\n\tfle.d\t%0,%1,%2\n\tfsflags %3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fle_quietdfsi4 },
    &operand_data[192],
    3,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1673 */
  {
    "flt_quietdfdi4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "frflags\t%3\n\tflt.d\t%0,%1,%2\n\tfsflags %3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_flt_quietdfdi4 },
    &operand_data[196],
    3,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1673 */
  {
    "fle_quietdfdi4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "frflags\t%3\n\tfle.d\t%0,%1,%2\n\tfsflags %3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_fle_quietdfdi4 },
    &operand_data[196],
    3,
    4,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1686 */
  {
    "*seq_zero_sisi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "seqz\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[28],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1686 */
  {
    "*seq_zero_disi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "seqz\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[200],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1686 */
  {
    "*seq_zero_didi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "seqz\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[31],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1695 */
  {
    "*sne_zero_sisi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "snez\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[28],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1695 */
  {
    "*sne_zero_disi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "snez\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[200],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1695 */
  {
    "*sne_zero_didi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "snez\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[31],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1704 */
  {
    "*sgt_sisi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sgt\t%0,%1,%z2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[202],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1704 */
  {
    "*sgtu_sisi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sgtu\t%0,%1,%z2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[202],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1704 */
  {
    "*sgt_disi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sgt\t%0,%1,%z2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[205],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1704 */
  {
    "*sgtu_disi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sgtu\t%0,%1,%z2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[205],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1704 */
  {
    "*sgt_didi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sgt\t%0,%1,%z2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[208],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1704 */
  {
    "*sgtu_didi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sgtu\t%0,%1,%z2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[208],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1713 */
  {
    "*sge_sisi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "slt\t%0,zero,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[28],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1713 */
  {
    "*sgeu_sisi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sltu\t%0,zero,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[28],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1713 */
  {
    "*sge_disi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "slt\t%0,zero,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[200],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1713 */
  {
    "*sgeu_disi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sltu\t%0,zero,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[200],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1713 */
  {
    "*sge_didi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "slt\t%0,zero,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[31],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1713 */
  {
    "*sgeu_didi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sltu\t%0,zero,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[31],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1722 */
  {
    "*slt_sisi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "slt\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[135],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1722 */
  {
    "*sltu_sisi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sltu\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[135],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1722 */
  {
    "*slt_disi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "slt\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[211],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1722 */
  {
    "*sltu_disi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sltu\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[211],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1722 */
  {
    "*slt_didi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "slt\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[138],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1722 */
  {
    "*sltu_didi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sltu\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[138],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1731 */
  {
    "*sle_sisi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_199 },
#else
    { 0, 0, output_199 },
#endif
    { 0 },
    &operand_data[214],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1731 */
  {
    "*sleu_sisi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_200 },
#else
    { 0, 0, output_200 },
#endif
    { 0 },
    &operand_data[214],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1731 */
  {
    "*sle_disi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_201 },
#else
    { 0, 0, output_201 },
#endif
    { 0 },
    &operand_data[217],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1731 */
  {
    "*sleu_disi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_202 },
#else
    { 0, 0, output_202 },
#endif
    { 0 },
    &operand_data[217],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1731 */
  {
    "*sle_didi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_203 },
#else
    { 0, 0, output_203 },
#endif
    { 0 },
    &operand_data[220],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1731 */
  {
    "*sleu_didi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_204 },
#else
    { 0, 0, output_204 },
#endif
    { 0 },
    &operand_data[220],
    3,
    3,
    0,
    1,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1752 */
  {
    "jump",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "j\t%l0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_jump },
    &operand_data[144],
    1,
    1,
    0,
    0,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1772 */
  {
    "indirect_jumpsi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "jr\t%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_indirect_jumpsi },
    &operand_data[223],
    1,
    1,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1772 */
  {
    "indirect_jumpdi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "jr\t%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_indirect_jumpdi },
    &operand_data[224],
    1,
    1,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1796 */
  {
    "tablejumpsi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "jr\t%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_tablejumpsi },
    &operand_data[225],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1796 */
  {
    "tablejumpdi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "jr\t%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_tablejumpdi },
    &operand_data[227],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1824 */
  {
    "blockage",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_blockage },
    &operand_data[0],
    0,
    0,
    0,
    0,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1855 */
  {
    "simple_return",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "ret",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_simple_return },
    &operand_data[0],
    0,
    0,
    0,
    0,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1864 */
  {
    "simple_return_internal",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "jr\t%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_simple_return_internal },
    &operand_data[229],
    1,
    1,
    0,
    0,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1889 */
  {
    "eh_set_lr_si",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "#",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_eh_set_lr_si },
    &operand_data[230],
    1,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1895 */
  {
    "eh_set_lr_di",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "#",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_eh_set_lr_di },
    &operand_data[232],
    1,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1930 */
  {
    "sibcall_internal",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .multi = output_215 },
#else
    { 0, output_215, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_sibcall_internal },
    &operand_data[234],
    2,
    2,
    0,
    3,
    2
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1952 */
  {
    "sibcall_value_internal",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .multi = output_216 },
#else
    { 0, output_216, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_sibcall_value_internal },
    &operand_data[235],
    3,
    3,
    0,
    3,
    2
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1975 */
  {
    "call_internal",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .multi = output_217 },
#else
    { 0, output_217, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_call_internal },
    &operand_data[238],
    2,
    2,
    0,
    3,
    2
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1998 */
  {
    "call_value_internal",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .multi = output_218 },
#else
    { 0, output_218, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_call_value_internal },
    &operand_data[237],
    3,
    3,
    0,
    3,
    2
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:2033 */
  {
    "nop",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "nop",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_nop },
    &operand_data[0],
    0,
    0,
    0,
    0,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:2040 */
  {
    "trap",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "ebreak",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_trap },
    &operand_data[0],
    0,
    0,
    0,
    0,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:2045 */
  {
    "gpr_save",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .function = output_221 },
#else
    { 0, 0, output_221 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_gpr_save },
    &operand_data[240],
    1,
    1,
    0,
    0,
    3
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:2052 */
  {
    "gpr_restore",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "tail\t__riscv_restore_%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_gpr_restore },
    &operand_data[240],
    1,
    1,
    0,
    0,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:2057 */
  {
    "gpr_restore_return",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_gpr_restore_return },
    &operand_data[229],
    1,
    1,
    0,
    0,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:2064 */
  {
    "riscv_frflags",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "frflags %0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_riscv_frflags },
    &operand_data[19],
    1,
    1,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:2070 */
  {
    "riscv_fsflags",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fsflags %0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_riscv_fsflags },
    &operand_data[241],
    1,
    1,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:2075 */
  {
    "stack_tiesi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_stack_tiesi },
    &operand_data[29],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:2075 */
  {
    "stack_tiedi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_stack_tiedi },
    &operand_data[32],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:51 */
  {
    "mem_thread_fence_1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fence\tiorw,iorw",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_mem_thread_fence_1 },
    &operand_data[242],
    2,
    2,
    1,
    0,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:61 */
  {
    "atomic_storesi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F2amoswap.w%A2 zero,%z1,%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_storesi },
    &operand_data[244],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:61 */
  {
    "atomic_storedi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F2amoswap.d%A2 zero,%z1,%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_storedi },
    &operand_data[247],
    3,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:71 */
  {
    "atomic_addsi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F2amoadd.w%A2 zero,%z1,%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_addsi },
    &operand_data[250],
    3,
    3,
    1,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:71 */
  {
    "atomic_orsi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F2amoor.w%A2 zero,%z1,%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_orsi },
    &operand_data[250],
    3,
    3,
    1,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:71 */
  {
    "atomic_xorsi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F2amoxor.w%A2 zero,%z1,%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_xorsi },
    &operand_data[250],
    3,
    3,
    1,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:71 */
  {
    "atomic_andsi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F2amoand.w%A2 zero,%z1,%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_andsi },
    &operand_data[250],
    3,
    3,
    1,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:71 */
  {
    "atomic_adddi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F2amoadd.d%A2 zero,%z1,%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_adddi },
    &operand_data[253],
    3,
    3,
    1,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:71 */
  {
    "atomic_ordi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F2amoor.d%A2 zero,%z1,%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_ordi },
    &operand_data[253],
    3,
    3,
    1,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:71 */
  {
    "atomic_xordi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F2amoxor.d%A2 zero,%z1,%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_xordi },
    &operand_data[253],
    3,
    3,
    1,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:71 */
  {
    "atomic_anddi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F2amoand.d%A2 zero,%z1,%0",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_anddi },
    &operand_data[253],
    3,
    3,
    1,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:82 */
  {
    "atomic_fetch_addsi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F3amoadd.w%A3 %0,%z2,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_fetch_addsi },
    &operand_data[256],
    4,
    4,
    2,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:82 */
  {
    "atomic_fetch_orsi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F3amoor.w%A3 %0,%z2,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_fetch_orsi },
    &operand_data[256],
    4,
    4,
    2,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:82 */
  {
    "atomic_fetch_xorsi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F3amoxor.w%A3 %0,%z2,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_fetch_xorsi },
    &operand_data[256],
    4,
    4,
    2,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:82 */
  {
    "atomic_fetch_andsi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F3amoand.w%A3 %0,%z2,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_fetch_andsi },
    &operand_data[256],
    4,
    4,
    2,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:82 */
  {
    "atomic_fetch_adddi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F3amoadd.d%A3 %0,%z2,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_fetch_adddi },
    &operand_data[260],
    4,
    4,
    2,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:82 */
  {
    "atomic_fetch_ordi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F3amoor.d%A3 %0,%z2,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_fetch_ordi },
    &operand_data[260],
    4,
    4,
    2,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:82 */
  {
    "atomic_fetch_xordi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F3amoxor.d%A3 %0,%z2,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_fetch_xordi },
    &operand_data[260],
    4,
    4,
    2,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:82 */
  {
    "atomic_fetch_anddi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F3amoand.d%A3 %0,%z2,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_fetch_anddi },
    &operand_data[260],
    4,
    4,
    2,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:95 */
  {
    "atomic_exchangesi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F3amoswap.w%A3 %0,%z2,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_exchangesi },
    &operand_data[264],
    4,
    4,
    1,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:95 */
  {
    "atomic_exchangedi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F3amoswap.d%A3 %0,%z2,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_exchangedi },
    &operand_data[268],
    4,
    4,
    1,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:107 */
  {
    "atomic_cas_value_strongsi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F5 1: lr.w%A5 %0,%1; bne %0,%z2,1f; sc.w%A4 %6,%z3,%1; bnez %6,1b; 1:",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_cas_value_strongsi },
    &operand_data[272],
    6,
    7,
    1,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:107 */
  {
    "atomic_cas_value_strongdi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "%F5 1: lr.d%A5 %0,%1; bne %0,%z2,1f; sc.d%A4 %6,%z3,%1; bnez %6,1b; 1:",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_cas_value_strongdi },
    &operand_data[279],
    6,
    7,
    1,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:25 */
  {
    "*local_pic_load_sqi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "lb\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[286],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:25 */
  {
    "*local_pic_load_shi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "lh\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[288],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:25 */
  {
    "*local_pic_load_ssi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "lw\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[290],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:25 */
  {
    "*local_pic_load_sdi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "ld\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[292],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:32 */
  {
    "*local_pic_load_uqi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "lbu\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[286],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:32 */
  {
    "*local_pic_load_uhi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "lhu\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[288],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:32 */
  {
    "*local_pic_load_usi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "lwu\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[290],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:39 */
  {
    "*local_pic_loadsf",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "flw\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[294],
    2,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:39 */
  {
    "*local_pic_loaddf",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fld\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[297],
    2,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:47 */
  {
    "*local_pic_loadsf",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "flw\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[300],
    2,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:47 */
  {
    "*local_pic_loaddf",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fld\t%0,%1,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[303],
    2,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:55 */
  {
    "*local_pic_loaduqi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "lbu\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[288],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:55 */
  {
    "*local_pic_loaduqi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "lbu\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[290],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:55 */
  {
    "*local_pic_loaduqi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "lbu\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[292],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:55 */
  {
    "*local_pic_loaduhi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "lhu\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[288],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:55 */
  {
    "*local_pic_loaduhi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "lhu\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[290],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:55 */
  {
    "*local_pic_loaduhi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "lhu\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[292],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:55 */
  {
    "*local_pic_loadusi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "lwu\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[288],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:55 */
  {
    "*local_pic_loadusi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "lwu\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[290],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:55 */
  {
    "*local_pic_loadusi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "lwu\t%0,%1",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[292],
    2,
    2,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:62 */
  {
    "*local_pic_storediqi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sb\t%z1,%0,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[306],
    2,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:62 */
  {
    "*local_pic_storedihi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sh\t%z1,%0,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[309],
    2,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:62 */
  {
    "*local_pic_storedisi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sw\t%z1,%0,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[312],
    2,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:62 */
  {
    "*local_pic_storedidi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sd\t%z1,%0,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[315],
    2,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:70 */
  {
    "*local_pic_storesiqi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sb\t%z1,%0,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[318],
    2,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:70 */
  {
    "*local_pic_storesihi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sh\t%z1,%0,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[321],
    2,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:70 */
  {
    "*local_pic_storesisi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sw\t%z1,%0,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[324],
    2,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:70 */
  {
    "*local_pic_storesidi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "sd\t%z1,%0,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[327],
    2,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:78 */
  {
    "*local_pic_storedisf",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fsw\t%1,%0,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[330],
    2,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:78 */
  {
    "*local_pic_storedidf",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fsd\t%1,%0,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[333],
    2,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:86 */
  {
    "*local_pic_storesisf",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fsw\t%1,%0,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[336],
    2,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/pic.md:86 */
  {
    "*local_pic_storesidf",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { .single =
#else
    {
#endif
    "fsd\t%1,%0,%2",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    },
#else
    0, 0 },
#endif
    { 0 },
    &operand_data[339],
    2,
    3,
    0,
    1,
    1
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:572 */
  {
    "mulditi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_mulditi3 },
    &operand_data[342],
    3,
    3,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:572 */
  {
    "umulditi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_umulditi3 },
    &operand_data[342],
    3,
    3,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:603 */
  {
    "usmulditi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_usmulditi3 },
    &operand_data[342],
    3,
    3,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:634 */
  {
    "mulsidi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_mulsidi3 },
    &operand_data[34],
    3,
    3,
    0,
    1,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:634 */
  {
    "umulsidi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_umulsidi3 },
    &operand_data[34],
    3,
    3,
    0,
    1,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:665 */
  {
    "usmulsidi3",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_usmulsidi3 },
    &operand_data[34],
    3,
    3,
    0,
    1,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1225 */
  {
    "movdi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_movdi },
    &operand_data[345],
    2,
    2,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1256 */
  {
    "movsi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_movsi },
    &operand_data[347],
    2,
    2,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1281 */
  {
    "movhi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_movhi },
    &operand_data[349],
    2,
    2,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1322 */
  {
    "movqi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_movqi },
    &operand_data[351],
    2,
    2,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1342 */
  {
    "movsf",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_movsf },
    &operand_data[353],
    2,
    2,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1373 */
  {
    "movdf",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_movdf },
    &operand_data[355],
    2,
    2,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1427 */
  {
    "clear_cache",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_clear_cache },
    &operand_data[357],
    2,
    2,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1540 */
  {
    "condjump",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_condjump },
    &operand_data[359],
    2,
    2,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1546 */
  {
    "cbranchqi4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_cbranchqi4 },
    &operand_data[361],
    4,
    4,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1546 */
  {
    "cbranchsi4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_cbranchsi4 },
    &operand_data[365],
    4,
    4,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1546 */
  {
    "cbranchdi4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_cbranchdi4 },
    &operand_data[369],
    4,
    4,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1560 */
  {
    "cbranchsf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_cbranchsf4 },
    &operand_data[373],
    4,
    4,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1560 */
  {
    "cbranchdf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_cbranchdf4 },
    &operand_data[377],
    4,
    4,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1639 */
  {
    "cstoresi4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_cstoresi4 },
    &operand_data[381],
    4,
    4,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1639 */
  {
    "cstoredi4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_cstoredi4 },
    &operand_data[385],
    4,
    4,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1651 */
  {
    "cstoresf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_cstoresf4 },
    &operand_data[389],
    4,
    4,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1651 */
  {
    "cstoredf4",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_cstoredf4 },
    &operand_data[393],
    4,
    4,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1760 */
  {
    "indirect_jump",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_indirect_jump },
    &operand_data[397],
    1,
    1,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1779 */
  {
    "tablejump",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_tablejump },
    &operand_data[397],
    2,
    2,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1812 */
  {
    "prologue",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_prologue },
    &operand_data[0],
    0,
    0,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1831 */
  {
    "epilogue",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_epilogue },
    &operand_data[0],
    0,
    0,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1839 */
  {
    "sibcall_epilogue",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_sibcall_epilogue },
    &operand_data[0],
    0,
    0,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1850 */
  {
    "return",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_return },
    &operand_data[0],
    0,
    0,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1873 */
  {
    "eh_return",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_eh_return },
    &operand_data[399],
    1,
    1,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1918 */
  {
    "sibcall",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_sibcall },
    &operand_data[400],
    4,
    4,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1940 */
  {
    "sibcall_value",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_sibcall_value },
    &operand_data[400],
    4,
    4,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1963 */
  {
    "call",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_call },
    &operand_data[400],
    4,
    4,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:1986 */
  {
    "call_value",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_call_value },
    &operand_data[400],
    4,
    4,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/riscv.md:2012 */
  {
    "untyped_call",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_untyped_call },
    &operand_data[400],
    3,
    3,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:36 */
  {
    "mem_thread_fence",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_mem_thread_fence },
    &operand_data[99],
    1,
    1,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:121 */
  {
    "atomic_compare_and_swapsi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_compare_and_swapsi },
    &operand_data[404],
    8,
    8,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:121 */
  {
    "atomic_compare_and_swapdi",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_compare_and_swapdi },
    &operand_data[412],
    8,
    8,
    0,
    0,
    0
  },
  /* ../../riscv-gcc/gcc/config/riscv/sync.md:155 */
  {
    "atomic_test_and_set",
#if HAVE_DESIGNATED_UNION_INITIALIZERS
    { 0 },
#else
    { 0, 0, 0 },
#endif
    { (insn_gen_fn::stored_funcptr) gen_atomic_test_and_set },
    &operand_data[420],
    3,
    3,
    0,
    1,
    0
  },
};


const char *
get_insn_name (int code)
{
  if (code == NOOP_MOVE_INSN_CODE)
    return "NOOP_MOVE";
  else
    return insn_data[code].name;
}
