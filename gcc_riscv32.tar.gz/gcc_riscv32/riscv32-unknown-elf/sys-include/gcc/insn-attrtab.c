/* Generated automatically by the program `genattrtab'
   from the machine description file `md'.  */

#include "config.h"
#include "system.h"
#include "coretypes.h"
#include "backend.h"
#include "predict.h"
#include "tree.h"
#include "rtl.h"
#include "alias.h"
#include "options.h"
#include "varasm.h"
#include "stor-layout.h"
#include "calls.h"
#include "insn-attr.h"
#include "memmodel.h"
#include "tm_p.h"
#include "insn-config.h"
#include "recog.h"
#include "regs.h"
#include "real.h"
#include "output.h"
#include "toplev.h"
#include "flags.h"
#include "emit-rtl.h"

#define operands recog_data.operand

int
insn_current_length (rtx_insn *insn ATTRIBUTE_UNUSED)
{
  enum attr_type cached_type ATTRIBUTE_UNUSED;
  enum attr_move_type cached_move_type ATTRIBUTE_UNUSED;
  enum attr_dword_mode cached_dword_mode ATTRIBUTE_UNUSED;

  switch (recog_memoized (insn))
    {
    case 158:  /* *branch_zerodi */
    case 157:  /* *branch_zerosi */
    case 156:  /* *branch_orderdi */
    case 155:  /* *branch_ordersi */
      extract_insn_cached (insn);
      if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (4088)) && (((insn_current_reference_address (insn)) - (INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0)) <= (4092)))
        {
	  return 4;
        }
      else
        {
	  return 8;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
      /* FALLTHRU */
      extract_insn_cached (insn);
      if (get_attr_type (insn) == TYPE_BRANCH)
        {
	  if ((((INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0) - (insn_current_reference_address (insn))) <= (4088)) && (((insn_current_reference_address (insn)) - (INSN_ADDRESSES_SET_P () ? INSN_ADDRESSES (INSN_UID (GET_CODE (operands[0]) == LABEL_REF ? XEXP (operands[0], 0) : operands[0])) : 0)) <= (4092)))
	    {
	      return 4;
	    }
	  else
	    {
	      return 8;
	    }
        }
      else
        {
	  return 0;
        }

    default:
      return 0;

    }
}

int
insn_variable_length_p (rtx_insn *insn ATTRIBUTE_UNUSED)
{
  enum attr_type cached_type ATTRIBUTE_UNUSED;
  enum attr_move_type cached_move_type ATTRIBUTE_UNUSED;
  enum attr_dword_mode cached_dword_mode ATTRIBUTE_UNUSED;

  switch (recog_memoized (insn))
    {
    case 158:  /* *branch_zerodi */
    case 157:  /* *branch_zerosi */
    case 156:  /* *branch_orderdi */
    case 155:  /* *branch_ordersi */
      return 1;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
      /* FALLTHRU */
      if (get_attr_type (insn) == TYPE_BRANCH)
        {
	  return 1;
        }
      else
        {
	  return 0;
        }

    default:
      return 0;

    }
}

int
insn_min_length (rtx_insn *insn ATTRIBUTE_UNUSED)
{
  enum attr_type cached_type ATTRIBUTE_UNUSED;
  enum attr_move_type cached_move_type ATTRIBUTE_UNUSED;
  enum attr_dword_mode cached_dword_mode ATTRIBUTE_UNUSED;

  switch (recog_memoized (insn))
    {
    case 143:  /* *movdf_softfloat */
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && ((
#line 109 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) == (0)))
        {
	  return 8;
        }
      else if (which_alternative == 1)
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else if (!((1 << which_alternative) & 0x3))
        {
	  return 
#line 222 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[0], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 142:  /* *movdf_hardfloat_rv64 */
      extract_constrain_insn_cached (insn);
      if ((((1 << which_alternative) & 0xe2)) && ((
#line 109 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) == (0)))
        {
	  return 8;
        }
      else if (((1 << which_alternative) & 0x104))
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else if (!((1 << which_alternative) & 0x1e7))
        {
	  return 
#line 222 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[0], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 141:  /* *movdf_hardfloat_rv32 */
      extract_constrain_insn_cached (insn);
      if ((((1 << which_alternative) & 0x22)) && ((
#line 109 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) == (0)))
        {
	  return 8;
        }
      else if (((1 << which_alternative) & 0x44))
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else if (!((1 << which_alternative) & 0x67))
        {
	  return 
#line 222 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[0], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 140:  /* *movsf_softfloat */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else if (!((1 << which_alternative) & 0x3))
        {
	  return 
#line 222 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[0], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 139:  /* *movsf_hardfloat */
      extract_constrain_insn_cached (insn);
      if (((1 << which_alternative) & 0x104))
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else if (!((1 << which_alternative) & 0x1e7))
        {
	  return 
#line 222 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[0], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 138:  /* *movqi_internal */
    case 133:  /* *movhi_internal */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 2)
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else if (which_alternative == 3)
        {
	  return 
#line 222 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[0], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 132:  /* *movsi_internal */
      extract_constrain_insn_cached (insn);
      if (((1 << which_alternative) & 0x24))
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else if (!((1 << which_alternative) & 0x77))
        {
	  return 
#line 222 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[0], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 131:  /* *movdi_64bit */
    case 130:  /* *movdi_32bit */
      extract_constrain_insn_cached (insn);
      if ((((1 << which_alternative) & 0x51)) && ((
#line 109 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) == (0)))
        {
	  return 8;
        }
      else if ((which_alternative == 1) && ((
#line 109 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) == (0)))
        {
	  return 
#line 215 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_split_const_insns (operands[1]) * 4);
        }
      else if (((1 << which_alternative) & 0x24))
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else if (!((1 << which_alternative) & 0xf7))
        {
	  return 
#line 222 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[0], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 86:  /* extendsidi2 */
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && ((
#line 109 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) == (0)))
        {
	  return 8;
        }
      else if (which_alternative != 0)
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 85:  /* zero_extendqidi2 */
    case 84:  /* zero_extendqisi2 */
    case 83:  /* zero_extendqihi2 */
      extract_constrain_insn_cached (insn);
      if (which_alternative != 0)
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 92:  /* extendhidi2 */
    case 91:  /* extendhisi2 */
    case 90:  /* extendhihi2 */
    case 89:  /* extendqidi2 */
    case 88:  /* extendqisi2 */
    case 87:  /* extendqihi2 */
    case 82:  /* zero_extendhidi2 */
    case 81:  /* zero_extendhisi2 */
    case 80:  /* zero_extendsidi2 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 8;
        }
      else
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }

    case 218:  /* call_value_internal */
    case 217:  /* call_internal */
    case 216:  /* sibcall_value_internal */
    case 215:  /* sibcall_internal */
    case 166:  /* *cstoredfdi4 */
    case 165:  /* *cstoredfsi4 */
    case 164:  /* *cstoresfdi4 */
    case 163:  /* *cstoresfsi4 */
    case 125:  /* got_load_tls_iedi */
    case 124:  /* got_load_tls_iesi */
    case 123:  /* got_load_tls_gddi */
    case 122:  /* got_load_tls_gdsi */
    case 119:  /* got_loaddi */
    case 118:  /* got_loadsi */
    case 282:  /* *local_pic_storesidf */
    case 281:  /* *local_pic_storesisf */
    case 280:  /* *local_pic_storedidf */
    case 279:  /* *local_pic_storedisf */
    case 278:  /* *local_pic_storesidi */
    case 277:  /* *local_pic_storesisi */
    case 276:  /* *local_pic_storesihi */
    case 275:  /* *local_pic_storesiqi */
    case 274:  /* *local_pic_storedidi */
    case 273:  /* *local_pic_storedisi */
    case 272:  /* *local_pic_storedihi */
    case 271:  /* *local_pic_storediqi */
    case 270:  /* *local_pic_loadusi */
    case 269:  /* *local_pic_loadusi */
    case 268:  /* *local_pic_loadusi */
    case 267:  /* *local_pic_loaduhi */
    case 266:  /* *local_pic_loaduhi */
    case 265:  /* *local_pic_loaduhi */
    case 264:  /* *local_pic_loaduqi */
    case 263:  /* *local_pic_loaduqi */
    case 262:  /* *local_pic_loaduqi */
    case 261:  /* *local_pic_loaddf */
    case 260:  /* *local_pic_loadsf */
    case 259:  /* *local_pic_loaddf */
    case 258:  /* *local_pic_loadsf */
    case 257:  /* *local_pic_load_usi */
    case 256:  /* *local_pic_load_uhi */
    case 255:  /* *local_pic_load_uqi */
    case 254:  /* *local_pic_load_sdi */
    case 253:  /* *local_pic_load_ssi */
    case 252:  /* *local_pic_load_shi */
    case 251:  /* *local_pic_load_sqi */
    case 248:  /* atomic_exchangedi */
    case 247:  /* atomic_exchangesi */
    case 246:  /* atomic_fetch_anddi */
    case 245:  /* atomic_fetch_xordi */
    case 244:  /* atomic_fetch_ordi */
    case 243:  /* atomic_fetch_adddi */
    case 242:  /* atomic_fetch_andsi */
    case 241:  /* atomic_fetch_xorsi */
    case 240:  /* atomic_fetch_orsi */
    case 239:  /* atomic_fetch_addsi */
    case 238:  /* atomic_anddi */
    case 237:  /* atomic_xordi */
    case 236:  /* atomic_ordi */
    case 235:  /* atomic_adddi */
    case 234:  /* atomic_andsi */
    case 233:  /* atomic_xorsi */
    case 232:  /* atomic_orsi */
    case 231:  /* atomic_addsi */
    case 230:  /* atomic_storedi */
    case 229:  /* atomic_storesi */
      return 8;

    case 250:  /* atomic_cas_value_strongdi */
    case 249:  /* atomic_cas_value_strongsi */
      return 20 /* 0x14 */;

    case 210:  /* blockage */
    case 227:  /* stack_tiedi */
    case 226:  /* stack_tiesi */
      return 0;

    case 174:  /* fle_quietdfdi4 */
    case 173:  /* flt_quietdfdi4 */
    case 172:  /* fle_quietdfsi4 */
    case 171:  /* flt_quietdfsi4 */
    case 170:  /* fle_quietsfdi4 */
    case 169:  /* flt_quietsfdi4 */
    case 168:  /* fle_quietsfsi4 */
    case 167:  /* flt_quietsfsi4 */
      return 12 /* 0xc */;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
      /* FALLTHRU */
      extract_constrain_insn_cached (insn);
      if ((cached_type = get_attr_type (insn)) == TYPE_BRANCH)
        {
	  return 4;
        }
      else if (cached_type == TYPE_CALL)
        {
	  return 8;
        }
      else if (cached_type == TYPE_GHOST)
        {
	  return 0;
        }
      else if (get_attr_got (insn) == GOT_LOAD)
        {
	  return 8;
        }
      else if (cached_type == TYPE_FCMP)
        {
	  return 8;
        }
      else if ((cached_move_type = get_attr_move_type (insn)) == MOVE_TYPE_SHIFT_SHIFT)
        {
	  return 8;
        }
      else if (((cached_move_type == MOVE_TYPE_MTC) || (cached_move_type == MOVE_TYPE_MFC) || (cached_move_type == MOVE_TYPE_MOVE)) && ((cached_dword_mode = get_attr_dword_mode (insn)) == DWORD_MODE_YES))
        {
	  return 8;
        }
      else if ((cached_move_type == MOVE_TYPE_CONST) && ((cached_dword_mode = get_attr_dword_mode (insn)) == DWORD_MODE_YES))
        {
	  return 
#line 215 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_split_const_insns (operands[1]) * 4);
        }
      else if ((cached_move_type == MOVE_TYPE_LOAD) || (cached_move_type == MOVE_TYPE_FPLOAD))
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else if ((cached_move_type == MOVE_TYPE_STORE) || (cached_move_type == MOVE_TYPE_FPSTORE))
        {
	  return 
#line 222 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[0], insn) * 4);
        }
      else
        {
	  return 4;
        }

    default:
      return 4;

    }
}

int
insn_default_length (rtx_insn *insn ATTRIBUTE_UNUSED)
{
  enum attr_type cached_type ATTRIBUTE_UNUSED;
  enum attr_move_type cached_move_type ATTRIBUTE_UNUSED;
  enum attr_dword_mode cached_dword_mode ATTRIBUTE_UNUSED;

  switch (recog_memoized (insn))
    {
    case 143:  /* *movdf_softfloat */
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && ((
#line 109 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) == (0)))
        {
	  return 8;
        }
      else if (which_alternative == 1)
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else if (!((1 << which_alternative) & 0x3))
        {
	  return 
#line 222 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[0], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 142:  /* *movdf_hardfloat_rv64 */
      extract_constrain_insn_cached (insn);
      if ((((1 << which_alternative) & 0xe2)) && ((
#line 109 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) == (0)))
        {
	  return 8;
        }
      else if (((1 << which_alternative) & 0x104))
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else if (!((1 << which_alternative) & 0x1e7))
        {
	  return 
#line 222 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[0], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 141:  /* *movdf_hardfloat_rv32 */
      extract_constrain_insn_cached (insn);
      if ((((1 << which_alternative) & 0x22)) && ((
#line 109 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) == (0)))
        {
	  return 8;
        }
      else if (((1 << which_alternative) & 0x44))
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else if (!((1 << which_alternative) & 0x67))
        {
	  return 
#line 222 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[0], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 140:  /* *movsf_softfloat */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else if (!((1 << which_alternative) & 0x3))
        {
	  return 
#line 222 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[0], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 139:  /* *movsf_hardfloat */
      extract_constrain_insn_cached (insn);
      if (((1 << which_alternative) & 0x104))
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else if (!((1 << which_alternative) & 0x1e7))
        {
	  return 
#line 222 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[0], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 138:  /* *movqi_internal */
    case 133:  /* *movhi_internal */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 2)
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else if (which_alternative == 3)
        {
	  return 
#line 222 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[0], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 132:  /* *movsi_internal */
      extract_constrain_insn_cached (insn);
      if (((1 << which_alternative) & 0x24))
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else if (!((1 << which_alternative) & 0x77))
        {
	  return 
#line 222 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[0], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 131:  /* *movdi_64bit */
    case 130:  /* *movdi_32bit */
      extract_constrain_insn_cached (insn);
      if ((((1 << which_alternative) & 0x51)) && ((
#line 109 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) == (0)))
        {
	  return 8;
        }
      else if ((which_alternative == 1) && ((
#line 109 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) == (0)))
        {
	  return 
#line 215 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_split_const_insns (operands[1]) * 4);
        }
      else if (((1 << which_alternative) & 0x24))
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else if (!((1 << which_alternative) & 0xf7))
        {
	  return 
#line 222 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[0], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 86:  /* extendsidi2 */
      extract_constrain_insn_cached (insn);
      if ((which_alternative == 0) && ((
#line 109 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) == (0)))
        {
	  return 8;
        }
      else if (which_alternative != 0)
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 85:  /* zero_extendqidi2 */
    case 84:  /* zero_extendqisi2 */
    case 83:  /* zero_extendqihi2 */
      extract_constrain_insn_cached (insn);
      if (which_alternative != 0)
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else
        {
	  return 4;
        }

    case 92:  /* extendhidi2 */
    case 91:  /* extendhisi2 */
    case 90:  /* extendhihi2 */
    case 89:  /* extendqidi2 */
    case 88:  /* extendqisi2 */
    case 87:  /* extendqihi2 */
    case 82:  /* zero_extendhidi2 */
    case 81:  /* zero_extendhisi2 */
    case 80:  /* zero_extendsidi2 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return 8;
        }
      else
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }

    case 218:  /* call_value_internal */
    case 217:  /* call_internal */
    case 216:  /* sibcall_value_internal */
    case 215:  /* sibcall_internal */
    case 166:  /* *cstoredfdi4 */
    case 165:  /* *cstoredfsi4 */
    case 164:  /* *cstoresfdi4 */
    case 163:  /* *cstoresfsi4 */
    case 158:  /* *branch_zerodi */
    case 157:  /* *branch_zerosi */
    case 156:  /* *branch_orderdi */
    case 155:  /* *branch_ordersi */
    case 125:  /* got_load_tls_iedi */
    case 124:  /* got_load_tls_iesi */
    case 123:  /* got_load_tls_gddi */
    case 122:  /* got_load_tls_gdsi */
    case 119:  /* got_loaddi */
    case 118:  /* got_loadsi */
    case 282:  /* *local_pic_storesidf */
    case 281:  /* *local_pic_storesisf */
    case 280:  /* *local_pic_storedidf */
    case 279:  /* *local_pic_storedisf */
    case 278:  /* *local_pic_storesidi */
    case 277:  /* *local_pic_storesisi */
    case 276:  /* *local_pic_storesihi */
    case 275:  /* *local_pic_storesiqi */
    case 274:  /* *local_pic_storedidi */
    case 273:  /* *local_pic_storedisi */
    case 272:  /* *local_pic_storedihi */
    case 271:  /* *local_pic_storediqi */
    case 270:  /* *local_pic_loadusi */
    case 269:  /* *local_pic_loadusi */
    case 268:  /* *local_pic_loadusi */
    case 267:  /* *local_pic_loaduhi */
    case 266:  /* *local_pic_loaduhi */
    case 265:  /* *local_pic_loaduhi */
    case 264:  /* *local_pic_loaduqi */
    case 263:  /* *local_pic_loaduqi */
    case 262:  /* *local_pic_loaduqi */
    case 261:  /* *local_pic_loaddf */
    case 260:  /* *local_pic_loadsf */
    case 259:  /* *local_pic_loaddf */
    case 258:  /* *local_pic_loadsf */
    case 257:  /* *local_pic_load_usi */
    case 256:  /* *local_pic_load_uhi */
    case 255:  /* *local_pic_load_uqi */
    case 254:  /* *local_pic_load_sdi */
    case 253:  /* *local_pic_load_ssi */
    case 252:  /* *local_pic_load_shi */
    case 251:  /* *local_pic_load_sqi */
    case 248:  /* atomic_exchangedi */
    case 247:  /* atomic_exchangesi */
    case 246:  /* atomic_fetch_anddi */
    case 245:  /* atomic_fetch_xordi */
    case 244:  /* atomic_fetch_ordi */
    case 243:  /* atomic_fetch_adddi */
    case 242:  /* atomic_fetch_andsi */
    case 241:  /* atomic_fetch_xorsi */
    case 240:  /* atomic_fetch_orsi */
    case 239:  /* atomic_fetch_addsi */
    case 238:  /* atomic_anddi */
    case 237:  /* atomic_xordi */
    case 236:  /* atomic_ordi */
    case 235:  /* atomic_adddi */
    case 234:  /* atomic_andsi */
    case 233:  /* atomic_xorsi */
    case 232:  /* atomic_orsi */
    case 231:  /* atomic_addsi */
    case 230:  /* atomic_storedi */
    case 229:  /* atomic_storesi */
      return 8;

    case 250:  /* atomic_cas_value_strongdi */
    case 249:  /* atomic_cas_value_strongsi */
      return 20 /* 0x14 */;

    case 210:  /* blockage */
    case 227:  /* stack_tiedi */
    case 226:  /* stack_tiesi */
      return 0;

    case 174:  /* fle_quietdfdi4 */
    case 173:  /* flt_quietdfdi4 */
    case 172:  /* fle_quietdfsi4 */
    case 171:  /* flt_quietdfsi4 */
    case 170:  /* fle_quietsfdi4 */
    case 169:  /* flt_quietsfdi4 */
    case 168:  /* fle_quietsfsi4 */
    case 167:  /* flt_quietsfsi4 */
      return 12 /* 0xc */;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
      /* FALLTHRU */
      extract_constrain_insn_cached (insn);
      if ((cached_type = get_attr_type (insn)) == TYPE_BRANCH)
        {
	  return 8;
        }
      else if (cached_type == TYPE_CALL)
        {
	  return 8;
        }
      else if (cached_type == TYPE_GHOST)
        {
	  return 0;
        }
      else if (get_attr_got (insn) == GOT_LOAD)
        {
	  return 8;
        }
      else if (cached_type == TYPE_FCMP)
        {
	  return 8;
        }
      else if ((cached_move_type = get_attr_move_type (insn)) == MOVE_TYPE_SHIFT_SHIFT)
        {
	  return 8;
        }
      else if (((cached_move_type == MOVE_TYPE_MTC) || (cached_move_type == MOVE_TYPE_MFC) || (cached_move_type == MOVE_TYPE_MOVE)) && ((cached_dword_mode = get_attr_dword_mode (insn)) == DWORD_MODE_YES))
        {
	  return 8;
        }
      else if ((cached_move_type == MOVE_TYPE_CONST) && ((cached_dword_mode = get_attr_dword_mode (insn)) == DWORD_MODE_YES))
        {
	  return 
#line 215 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_split_const_insns (operands[1]) * 4);
        }
      else if ((cached_move_type == MOVE_TYPE_LOAD) || (cached_move_type == MOVE_TYPE_FPLOAD))
        {
	  return 
#line 220 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[1], insn) * 4);
        }
      else if ((cached_move_type == MOVE_TYPE_STORE) || (cached_move_type == MOVE_TYPE_FPSTORE))
        {
	  return 
#line 222 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(riscv_load_store_insns (operands[0], insn) * 4);
        }
      else
        {
	  return 4;
        }

    default:
      return 4;

    }
}

int
bypass_p (rtx_insn *insn ATTRIBUTE_UNUSED)
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
      /* FALLTHRU */
    default:
      return 0;

    }
}

int
num_delay_slots (rtx_insn *insn ATTRIBUTE_UNUSED)
{
  switch (recog_memoized (insn))
    {
    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
      /* FALLTHRU */
    default:
      return 0;

    }
}

enum attr_cannot_copy
get_attr_cannot_copy (rtx_insn *insn ATTRIBUTE_UNUSED)
{
  switch (recog_memoized (insn))
    {
    case 126:  /* auipcsi */
    case 127:  /* auipcdi */
      return CANNOT_COPY_YES;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
      /* FALLTHRU */
    default:
      return CANNOT_COPY_NO;

    }
}

enum attr_dword_mode
get_attr_dword_mode (rtx_insn *insn ATTRIBUTE_UNUSED)
{
  enum attr_mode cached_mode ATTRIBUTE_UNUSED;

  switch (recog_memoized (insn))
    {
    case 204:  /* *sleu_didi */
    case 203:  /* *sle_didi */
    case 202:  /* *sleu_disi */
    case 201:  /* *sle_disi */
    case 198:  /* *sltu_didi */
    case 197:  /* *slt_didi */
    case 196:  /* *sltu_disi */
    case 195:  /* *slt_disi */
    case 192:  /* *sgeu_didi */
    case 191:  /* *sge_didi */
    case 190:  /* *sgeu_disi */
    case 189:  /* *sge_disi */
    case 186:  /* *sgtu_didi */
    case 185:  /* *sgt_didi */
    case 184:  /* *sgtu_disi */
    case 183:  /* *sgt_disi */
    case 180:  /* *sne_zero_didi */
    case 179:  /* *sne_zero_disi */
    case 177:  /* *seq_zero_didi */
    case 176:  /* *seq_zero_disi */
    case 174:  /* fle_quietdfdi4 */
    case 173:  /* flt_quietdfdi4 */
    case 172:  /* fle_quietdfsi4 */
    case 171:  /* flt_quietdfsi4 */
    case 166:  /* *cstoredfdi4 */
    case 165:  /* *cstoredfsi4 */
    case 151:  /* lshrdi3 */
    case 150:  /* ashrdi3 */
    case 149:  /* ashldi3 */
    case 143:  /* *movdf_softfloat */
    case 142:  /* *movdf_hardfloat_rv64 */
    case 141:  /* *movdf_hardfloat_rv32 */
    case 131:  /* *movdi_64bit */
    case 130:  /* *movdi_32bit */
    case 129:  /* *lowdi */
    case 125:  /* got_load_tls_iedi */
    case 123:  /* got_load_tls_gddi */
    case 121:  /* tls_add_tp_ledi */
    case 119:  /* got_loaddi */
    case 117:  /* lrounddfdi2 */
    case 116:  /* lrintdfdi2 */
    case 115:  /* lrounddfsi2 */
    case 114:  /* lrintdfsi2 */
    case 109:  /* floatunsdidf2 */
    case 108:  /* floatunssidf2 */
    case 105:  /* floatdidf2 */
    case 104:  /* floatsidf2 */
    case 101:  /* fixuns_truncdfdi2 */
    case 100:  /* fixuns_truncdfsi2 */
    case 97:  /* fix_truncdfdi2 */
    case 96:  /* fix_truncdfsi2 */
    case 93:  /* extendsfdf2 */
    case 86:  /* extendsidi2 */
    case 85:  /* zero_extendqidi2 */
    case 82:  /* zero_extendhidi2 */
    case 80:  /* zero_extendsidi2 */
    case 77:  /* one_cmpldi2 */
    case 72:  /* xordi3 */
    case 71:  /* iordi3 */
    case 70:  /* anddi3 */
    case 66:  /* smaxdf3 */
    case 64:  /* smindf3 */
    case 62:  /* negdf2 */
    case 60:  /* copysigndf3 */
    case 58:  /* absdf2 */
    case 56:  /* *fnmadf4 */
    case 54:  /* *fnmsdf4 */
    case 52:  /* *fmsdf4 */
    case 50:  /* *fmadf4 */
    case 48:  /* fnmadf4 */
    case 46:  /* fnmsdf4 */
    case 44:  /* fmsdf4 */
    case 42:  /* fmadf4 */
    case 40:  /* sqrtdf2 */
    case 38:  /* divdf3 */
    case 36:  /* *umodsi3_extended */
    case 35:  /* *modsi3_extended */
    case 34:  /* *udivsi3_extended */
    case 33:  /* *divsi3_extended */
    case 32:  /* umoddi3 */
    case 31:  /* moddi3 */
    case 30:  /* udivdi3 */
    case 29:  /* divdi3 */
    case 21:  /* usmuldi3_highpart */
    case 20:  /* umuldi3_highpart */
    case 19:  /* muldi3_highpart */
    case 16:  /* muldi3 */
    case 14:  /* muldf3 */
    case 9:  /* subdi3 */
    case 8:  /* subdf3 */
    case 4:  /* adddi3 */
    case 2:  /* adddf3 */
      extract_constrain_insn_cached (insn);
      if ((
#line 109 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) == (0))
        {
	  return DWORD_MODE_YES;
        }
      else
        {
	  return DWORD_MODE_NO;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
      /* FALLTHRU */
      extract_constrain_insn_cached (insn);
      if ((((cached_mode = get_attr_mode (insn)) == MODE_DI) || (cached_mode == MODE_DF)) && ((
#line 109 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) == (0)))
        {
	  return DWORD_MODE_YES;
        }
      else if (((cached_mode == MODE_TI) || (cached_mode == MODE_TF)) && ((
#line 113 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) != (0)))
        {
	  return DWORD_MODE_YES;
        }
      else
        {
	  return DWORD_MODE_NO;
        }

    default:
      return DWORD_MODE_NO;

    }
}

enum attr_got
get_attr_got (rtx_insn *insn ATTRIBUTE_UNUSED)
{
  switch (recog_memoized (insn))
    {
    case 118:  /* got_loadsi */
    case 119:  /* got_loaddi */
    case 122:  /* got_load_tls_gdsi */
    case 123:  /* got_load_tls_gddi */
    case 124:  /* got_load_tls_iesi */
    case 125:  /* got_load_tls_iedi */
      return GOT_LOAD;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
      /* FALLTHRU */
    default:
      return GOT_UNSET;

    }
}

enum attr_mode
get_attr_mode (rtx_insn *insn ATTRIBUTE_UNUSED)
{
  switch (recog_memoized (insn))
    {
    case 2:  /* adddf3 */
    case 8:  /* subdf3 */
    case 14:  /* muldf3 */
    case 38:  /* divdf3 */
    case 40:  /* sqrtdf2 */
    case 42:  /* fmadf4 */
    case 44:  /* fmsdf4 */
    case 46:  /* fnmsdf4 */
    case 48:  /* fnmadf4 */
    case 50:  /* *fmadf4 */
    case 52:  /* *fmsdf4 */
    case 54:  /* *fnmsdf4 */
    case 56:  /* *fnmadf4 */
    case 58:  /* absdf2 */
    case 60:  /* copysigndf3 */
    case 62:  /* negdf2 */
    case 64:  /* smindf3 */
    case 66:  /* smaxdf3 */
    case 93:  /* extendsfdf2 */
    case 96:  /* fix_truncdfsi2 */
    case 97:  /* fix_truncdfdi2 */
    case 100:  /* fixuns_truncdfsi2 */
    case 101:  /* fixuns_truncdfdi2 */
    case 104:  /* floatsidf2 */
    case 105:  /* floatdidf2 */
    case 108:  /* floatunssidf2 */
    case 109:  /* floatunsdidf2 */
    case 114:  /* lrintdfsi2 */
    case 115:  /* lrounddfsi2 */
    case 116:  /* lrintdfdi2 */
    case 117:  /* lrounddfdi2 */
    case 141:  /* *movdf_hardfloat_rv32 */
    case 142:  /* *movdf_hardfloat_rv64 */
    case 143:  /* *movdf_softfloat */
    case 165:  /* *cstoredfsi4 */
    case 166:  /* *cstoredfdi4 */
    case 171:  /* flt_quietdfsi4 */
    case 172:  /* fle_quietdfsi4 */
    case 173:  /* flt_quietdfdi4 */
    case 174:  /* fle_quietdfdi4 */
      return MODE_DF;

    case 1:  /* addsf3 */
    case 7:  /* subsf3 */
    case 13:  /* mulsf3 */
    case 37:  /* divsf3 */
    case 39:  /* sqrtsf2 */
    case 41:  /* fmasf4 */
    case 43:  /* fmssf4 */
    case 45:  /* fnmssf4 */
    case 47:  /* fnmasf4 */
    case 49:  /* *fmasf4 */
    case 51:  /* *fmssf4 */
    case 53:  /* *fnmssf4 */
    case 55:  /* *fnmasf4 */
    case 57:  /* abssf2 */
    case 59:  /* copysignsf3 */
    case 61:  /* negsf2 */
    case 63:  /* sminsf3 */
    case 65:  /* smaxsf3 */
    case 79:  /* truncdfsf2 */
    case 94:  /* fix_truncsfsi2 */
    case 95:  /* fix_truncsfdi2 */
    case 98:  /* fixuns_truncsfsi2 */
    case 99:  /* fixuns_truncsfdi2 */
    case 102:  /* floatsisf2 */
    case 103:  /* floatdisf2 */
    case 106:  /* floatunssisf2 */
    case 107:  /* floatunsdisf2 */
    case 110:  /* lrintsfsi2 */
    case 111:  /* lroundsfsi2 */
    case 112:  /* lrintsfdi2 */
    case 113:  /* lroundsfdi2 */
    case 139:  /* *movsf_hardfloat */
    case 140:  /* *movsf_softfloat */
    case 163:  /* *cstoresfsi4 */
    case 164:  /* *cstoresfdi4 */
    case 167:  /* flt_quietsfsi4 */
    case 168:  /* fle_quietsfsi4 */
    case 169:  /* flt_quietsfdi4 */
    case 170:  /* fle_quietsfdi4 */
      return MODE_SF;

    case 4:  /* adddi3 */
    case 9:  /* subdi3 */
    case 16:  /* muldi3 */
    case 19:  /* muldi3_highpart */
    case 20:  /* umuldi3_highpart */
    case 21:  /* usmuldi3_highpart */
    case 29:  /* divdi3 */
    case 30:  /* udivdi3 */
    case 31:  /* moddi3 */
    case 32:  /* umoddi3 */
    case 33:  /* *divsi3_extended */
    case 34:  /* *udivsi3_extended */
    case 35:  /* *modsi3_extended */
    case 36:  /* *umodsi3_extended */
    case 70:  /* anddi3 */
    case 71:  /* iordi3 */
    case 72:  /* xordi3 */
    case 77:  /* one_cmpldi2 */
    case 80:  /* zero_extendsidi2 */
    case 82:  /* zero_extendhidi2 */
    case 85:  /* zero_extendqidi2 */
    case 86:  /* extendsidi2 */
    case 119:  /* got_loaddi */
    case 121:  /* tls_add_tp_ledi */
    case 123:  /* got_load_tls_gddi */
    case 125:  /* got_load_tls_iedi */
    case 129:  /* *lowdi */
    case 130:  /* *movdi_32bit */
    case 131:  /* *movdi_64bit */
    case 149:  /* ashldi3 */
    case 150:  /* ashrdi3 */
    case 151:  /* lshrdi3 */
    case 176:  /* *seq_zero_disi */
    case 177:  /* *seq_zero_didi */
    case 179:  /* *sne_zero_disi */
    case 180:  /* *sne_zero_didi */
    case 183:  /* *sgt_disi */
    case 184:  /* *sgtu_disi */
    case 185:  /* *sgt_didi */
    case 186:  /* *sgtu_didi */
    case 189:  /* *sge_disi */
    case 190:  /* *sgeu_disi */
    case 191:  /* *sge_didi */
    case 192:  /* *sgeu_didi */
    case 195:  /* *slt_disi */
    case 196:  /* *sltu_disi */
    case 197:  /* *slt_didi */
    case 198:  /* *sltu_didi */
    case 201:  /* *sle_disi */
    case 202:  /* *sleu_disi */
    case 203:  /* *sle_didi */
    case 204:  /* *sleu_didi */
      return MODE_DI;

    case 3:  /* addsi3 */
    case 5:  /* *addsi3_extended */
    case 6:  /* *addsi3_extended2 */
    case 10:  /* subsi3 */
    case 11:  /* *subsi3_extended */
    case 12:  /* *subsi3_extended2 */
    case 15:  /* mulsi3 */
    case 17:  /* *mulsi3_extended */
    case 18:  /* *mulsi3_extended2 */
    case 22:  /* mulsi3_highpart */
    case 23:  /* umulsi3_highpart */
    case 24:  /* usmulsi3_highpart */
    case 25:  /* divsi3 */
    case 26:  /* udivsi3 */
    case 27:  /* modsi3 */
    case 28:  /* umodsi3 */
    case 67:  /* andsi3 */
    case 68:  /* iorsi3 */
    case 69:  /* xorsi3 */
    case 73:  /* *andsi3_internal */
    case 74:  /* *iorsi3_internal */
    case 75:  /* *xorsi3_internal */
    case 76:  /* one_cmplsi2 */
    case 78:  /* *one_cmplsi2_internal */
    case 81:  /* zero_extendhisi2 */
    case 84:  /* zero_extendqisi2 */
    case 87:  /* extendqihi2 */
    case 88:  /* extendqisi2 */
    case 89:  /* extendqidi2 */
    case 90:  /* extendhihi2 */
    case 91:  /* extendhisi2 */
    case 92:  /* extendhidi2 */
    case 118:  /* got_loadsi */
    case 120:  /* tls_add_tp_lesi */
    case 122:  /* got_load_tls_gdsi */
    case 124:  /* got_load_tls_iesi */
    case 128:  /* *lowsi */
    case 132:  /* *movsi_internal */
    case 146:  /* ashlsi3 */
    case 147:  /* ashrsi3 */
    case 148:  /* lshrsi3 */
    case 152:  /* *ashlsi3_extend */
    case 153:  /* *ashrsi3_extend */
    case 154:  /* *lshrsi3_extend */
    case 175:  /* *seq_zero_sisi */
    case 178:  /* *sne_zero_sisi */
    case 181:  /* *sgt_sisi */
    case 182:  /* *sgtu_sisi */
    case 187:  /* *sge_sisi */
    case 188:  /* *sgeu_sisi */
    case 193:  /* *slt_sisi */
    case 194:  /* *sltu_sisi */
    case 199:  /* *sle_sisi */
    case 200:  /* *sleu_sisi */
      return MODE_SI;

    case 83:  /* zero_extendqihi2 */
    case 133:  /* *movhi_internal */
    case 134:  /* *addhihi3 */
    case 135:  /* *addsihi3 */
    case 136:  /* *xorhihi3 */
    case 137:  /* *xorsihi3 */
      return MODE_HI;

    case 138:  /* *movqi_internal */
      return MODE_QI;

    case 155:  /* *branch_ordersi */
    case 156:  /* *branch_orderdi */
    case 157:  /* *branch_zerosi */
    case 158:  /* *branch_zerodi */
    case 205:  /* jump */
    case 206:  /* indirect_jumpsi */
    case 207:  /* indirect_jumpdi */
    case 208:  /* tablejumpsi */
    case 209:  /* tablejumpdi */
    case 210:  /* blockage */
    case 211:  /* simple_return */
    case 212:  /* simple_return_internal */
    case 219:  /* nop */
      return MODE_NONE;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
      /* FALLTHRU */
    default:
      return MODE_UNKNOWN;

    }
}

enum attr_move_type
get_attr_move_type (rtx_insn *insn ATTRIBUTE_UNUSED)
{
  switch (recog_memoized (insn))
    {
    case 83:  /* zero_extendqihi2 */
    case 84:  /* zero_extendqisi2 */
    case 85:  /* zero_extendqidi2 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return MOVE_TYPE_ANDI;
        }
      else
        {
	  return MOVE_TYPE_LOAD;
        }

    case 86:  /* extendsidi2 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return MOVE_TYPE_MOVE;
        }
      else
        {
	  return MOVE_TYPE_LOAD;
        }

    case 80:  /* zero_extendsidi2 */
    case 81:  /* zero_extendhisi2 */
    case 82:  /* zero_extendhidi2 */
    case 87:  /* extendqihi2 */
    case 88:  /* extendqisi2 */
    case 89:  /* extendqidi2 */
    case 90:  /* extendhihi2 */
    case 91:  /* extendhisi2 */
    case 92:  /* extendhidi2 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return MOVE_TYPE_SHIFT_SHIFT;
        }
      else
        {
	  return MOVE_TYPE_LOAD;
        }

    case 130:  /* *movdi_32bit */
    case 131:  /* *movdi_64bit */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return MOVE_TYPE_MOVE;
        }
      else if (which_alternative == 1)
        {
	  return MOVE_TYPE_CONST;
        }
      else if (which_alternative == 2)
        {
	  return MOVE_TYPE_LOAD;
        }
      else if (which_alternative == 3)
        {
	  return MOVE_TYPE_STORE;
        }
      else if (which_alternative == 4)
        {
	  return MOVE_TYPE_MTC;
        }
      else if (which_alternative == 5)
        {
	  return MOVE_TYPE_FPLOAD;
        }
      else if (which_alternative == 6)
        {
	  return MOVE_TYPE_MFC;
        }
      else if (which_alternative == 7)
        {
	  return MOVE_TYPE_FMOVE;
        }
      else
        {
	  return MOVE_TYPE_FPSTORE;
        }

    case 132:  /* *movsi_internal */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return MOVE_TYPE_MOVE;
        }
      else if (which_alternative == 1)
        {
	  return MOVE_TYPE_CONST;
        }
      else if (which_alternative == 2)
        {
	  return MOVE_TYPE_LOAD;
        }
      else if (which_alternative == 3)
        {
	  return MOVE_TYPE_STORE;
        }
      else if (which_alternative == 4)
        {
	  return MOVE_TYPE_MTC;
        }
      else if (which_alternative == 5)
        {
	  return MOVE_TYPE_FPLOAD;
        }
      else if (which_alternative == 6)
        {
	  return MOVE_TYPE_MFC;
        }
      else
        {
	  return MOVE_TYPE_FPSTORE;
        }

    case 133:  /* *movhi_internal */
    case 138:  /* *movqi_internal */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return MOVE_TYPE_MOVE;
        }
      else if (which_alternative == 1)
        {
	  return MOVE_TYPE_CONST;
        }
      else if (which_alternative == 2)
        {
	  return MOVE_TYPE_LOAD;
        }
      else if (which_alternative == 3)
        {
	  return MOVE_TYPE_STORE;
        }
      else if (which_alternative == 4)
        {
	  return MOVE_TYPE_MTC;
        }
      else
        {
	  return MOVE_TYPE_MFC;
        }

    case 141:  /* *movdf_hardfloat_rv32 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return MOVE_TYPE_FMOVE;
        }
      else if (which_alternative == 1)
        {
	  return MOVE_TYPE_MTC;
        }
      else if (which_alternative == 2)
        {
	  return MOVE_TYPE_FPLOAD;
        }
      else if (which_alternative == 3)
        {
	  return MOVE_TYPE_FPSTORE;
        }
      else if (which_alternative == 4)
        {
	  return MOVE_TYPE_STORE;
        }
      else if (which_alternative == 5)
        {
	  return MOVE_TYPE_MOVE;
        }
      else if (which_alternative == 6)
        {
	  return MOVE_TYPE_LOAD;
        }
      else
        {
	  return MOVE_TYPE_STORE;
        }

    case 139:  /* *movsf_hardfloat */
    case 142:  /* *movdf_hardfloat_rv64 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return MOVE_TYPE_FMOVE;
        }
      else if (which_alternative == 1)
        {
	  return MOVE_TYPE_MTC;
        }
      else if (which_alternative == 2)
        {
	  return MOVE_TYPE_FPLOAD;
        }
      else if (which_alternative == 3)
        {
	  return MOVE_TYPE_FPSTORE;
        }
      else if (which_alternative == 4)
        {
	  return MOVE_TYPE_STORE;
        }
      else if (which_alternative == 5)
        {
	  return MOVE_TYPE_MTC;
        }
      else if (which_alternative == 6)
        {
	  return MOVE_TYPE_MFC;
        }
      else if (which_alternative == 7)
        {
	  return MOVE_TYPE_MOVE;
        }
      else if (which_alternative == 8)
        {
	  return MOVE_TYPE_LOAD;
        }
      else
        {
	  return MOVE_TYPE_STORE;
        }

    case 140:  /* *movsf_softfloat */
    case 143:  /* *movdf_softfloat */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 0)
        {
	  return MOVE_TYPE_MOVE;
        }
      else if (which_alternative == 1)
        {
	  return MOVE_TYPE_LOAD;
        }
      else
        {
	  return MOVE_TYPE_STORE;
        }

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
      /* FALLTHRU */
    default:
      return MOVE_TYPE_UNKNOWN;

    }
}

enum attr_type
get_attr_type (rtx_insn *insn ATTRIBUTE_UNUSED)
{
  enum attr_move_type cached_move_type ATTRIBUTE_UNUSED;

  switch (recog_memoized (insn))
    {
    case 143:  /* *movdf_softfloat */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  return TYPE_LOAD;
        }
      else if (!((1 << which_alternative) & 0x3))
        {
	  return TYPE_STORE;
        }
      else if ((
#line 109 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) == (0))
        {
	  return TYPE_MULTI;
        }
      else
        {
	  return TYPE_MOVE;
        }

    case 142:  /* *movdf_hardfloat_rv64 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 8)
        {
	  return TYPE_LOAD;
        }
      else if (which_alternative == 2)
        {
	  return TYPE_FPLOAD;
        }
      else if (!((1 << which_alternative) & 0x1ef))
        {
	  return TYPE_STORE;
        }
      else if (which_alternative == 3)
        {
	  return TYPE_FPSTORE;
        }
      else if (((1 << which_alternative) & 0x22))
        {
	  return TYPE_MTC;
        }
      else if (which_alternative == 6)
        {
	  return TYPE_MFC;
        }
      else if (which_alternative == 0)
        {
	  return TYPE_FMOVE;
        }
      else if ((
#line 109 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) == (0))
        {
	  return TYPE_MULTI;
        }
      else
        {
	  return TYPE_MOVE;
        }

    case 141:  /* *movdf_hardfloat_rv32 */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 6)
        {
	  return TYPE_LOAD;
        }
      else if (which_alternative == 2)
        {
	  return TYPE_FPLOAD;
        }
      else if (!((1 << which_alternative) & 0x6f))
        {
	  return TYPE_STORE;
        }
      else if (which_alternative == 3)
        {
	  return TYPE_FPSTORE;
        }
      else if (which_alternative == 1)
        {
	  return TYPE_MTC;
        }
      else if (which_alternative == 0)
        {
	  return TYPE_FMOVE;
        }
      else if ((
#line 109 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) == (0))
        {
	  return TYPE_MULTI;
        }
      else
        {
	  return TYPE_MOVE;
        }

    case 140:  /* *movsf_softfloat */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 1)
        {
	  return TYPE_LOAD;
        }
      else if (!((1 << which_alternative) & 0x3))
        {
	  return TYPE_STORE;
        }
      else
        {
	  return TYPE_MOVE;
        }

    case 139:  /* *movsf_hardfloat */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 8)
        {
	  return TYPE_LOAD;
        }
      else if (which_alternative == 2)
        {
	  return TYPE_FPLOAD;
        }
      else if (!((1 << which_alternative) & 0x1ef))
        {
	  return TYPE_STORE;
        }
      else if (which_alternative == 3)
        {
	  return TYPE_FPSTORE;
        }
      else if (((1 << which_alternative) & 0x22))
        {
	  return TYPE_MTC;
        }
      else if (which_alternative == 6)
        {
	  return TYPE_MFC;
        }
      else if (which_alternative == 0)
        {
	  return TYPE_FMOVE;
        }
      else
        {
	  return TYPE_MOVE;
        }

    case 138:  /* *movqi_internal */
    case 133:  /* *movhi_internal */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 2)
        {
	  return TYPE_LOAD;
        }
      else if (which_alternative == 3)
        {
	  return TYPE_STORE;
        }
      else if (which_alternative == 4)
        {
	  return TYPE_MTC;
        }
      else if (!((1 << which_alternative) & 0x1f))
        {
	  return TYPE_MFC;
        }
      else if (which_alternative == 0)
        {
	  return TYPE_MOVE;
        }
      else
        {
	  return TYPE_CONST;
        }

    case 132:  /* *movsi_internal */
      extract_constrain_insn_cached (insn);
      if (which_alternative == 2)
        {
	  return TYPE_LOAD;
        }
      else if (which_alternative == 5)
        {
	  return TYPE_FPLOAD;
        }
      else if (which_alternative == 3)
        {
	  return TYPE_STORE;
        }
      else if (!((1 << which_alternative) & 0x7f))
        {
	  return TYPE_FPSTORE;
        }
      else if (which_alternative == 4)
        {
	  return TYPE_MTC;
        }
      else if (which_alternative == 6)
        {
	  return TYPE_MFC;
        }
      else if (which_alternative == 0)
        {
	  return TYPE_MOVE;
        }
      else
        {
	  return TYPE_CONST;
        }

    case 86:  /* extendsidi2 */
      extract_constrain_insn_cached (insn);
      if (which_alternative != 0)
        {
	  return TYPE_LOAD;
        }
      else if ((
#line 109 "../../riscv-gcc/gcc/config/riscv/riscv.md"
(TARGET_64BIT)) == (0))
        {
	  return TYPE_MULTI;
        }
      else
        {
	  return TYPE_MOVE;
        }

    case 85:  /* zero_extendqidi2 */
    case 84:  /* zero_extendqisi2 */
    case 83:  /* zero_extendqihi2 */
      extract_constrain_insn_cached (insn);
      if (which_alternative != 0)
        {
	  return TYPE_LOAD;
        }
      else
        {
	  return TYPE_LOGICAL;
        }

    case 92:  /* extendhidi2 */
    case 91:  /* extendhisi2 */
    case 90:  /* extendhihi2 */
    case 89:  /* extendqidi2 */
    case 88:  /* extendqisi2 */
    case 87:  /* extendqihi2 */
    case 82:  /* zero_extendhidi2 */
    case 81:  /* zero_extendhisi2 */
    case 80:  /* zero_extendsidi2 */
      extract_constrain_insn_cached (insn);
      if (which_alternative != 0)
        {
	  return TYPE_LOAD;
        }
      else
        {
	  return TYPE_MULTI;
        }

    case 130:  /* *movdi_32bit */
    case 131:  /* *movdi_64bit */
      if (get_attr_got (insn) == GOT_LOAD)
        {
	  return TYPE_LOAD;
        }
      else if ((cached_move_type = get_attr_move_type (insn)) == MOVE_TYPE_LOAD)
        {
	  return TYPE_LOAD;
        }
      else if (cached_move_type == MOVE_TYPE_FPLOAD)
        {
	  return TYPE_FPLOAD;
        }
      else if (cached_move_type == MOVE_TYPE_STORE)
        {
	  return TYPE_STORE;
        }
      else if (cached_move_type == MOVE_TYPE_FPSTORE)
        {
	  return TYPE_FPSTORE;
        }
      else if (cached_move_type == MOVE_TYPE_MTC)
        {
	  return TYPE_MTC;
        }
      else if (cached_move_type == MOVE_TYPE_MFC)
        {
	  return TYPE_MFC;
        }
      else if (cached_move_type == MOVE_TYPE_FMOVE)
        {
	  return TYPE_FMOVE;
        }
      else if (cached_move_type == MOVE_TYPE_ARITH)
        {
	  return TYPE_ARITH;
        }
      else if (cached_move_type == MOVE_TYPE_LOGICAL)
        {
	  return TYPE_LOGICAL;
        }
      else if (cached_move_type == MOVE_TYPE_ANDI)
        {
	  return TYPE_LOGICAL;
        }
      else if (cached_move_type == MOVE_TYPE_SHIFT_SHIFT)
        {
	  return TYPE_MULTI;
        }
      else if (((cached_move_type == MOVE_TYPE_MOVE) || (cached_move_type == MOVE_TYPE_CONST)) && (get_attr_dword_mode (insn) == DWORD_MODE_YES))
        {
	  return TYPE_MULTI;
        }
      else if (cached_move_type == MOVE_TYPE_MOVE)
        {
	  return TYPE_MOVE;
        }
      else if (cached_move_type == MOVE_TYPE_CONST)
        {
	  return TYPE_CONST;
        }
      else
        {
	  return TYPE_UNKNOWN;
        }

    case 210:  /* blockage */
      return TYPE_GHOST;

    case 219:  /* nop */
      return TYPE_NOP;

    case -1:
      if (GET_CODE (PATTERN (insn)) != ASM_INPUT
          && asm_noperands (PATTERN (insn)) < 0)
        fatal_insn_not_found (insn);
      /* FALLTHRU */
      return TYPE_MULTI;

    case 39:  /* sqrtsf2 */
    case 40:  /* sqrtdf2 */
      return TYPE_FSQRT;

    case 79:  /* truncdfsf2 */
    case 93:  /* extendsfdf2 */
    case 94:  /* fix_truncsfsi2 */
    case 95:  /* fix_truncsfdi2 */
    case 96:  /* fix_truncdfsi2 */
    case 97:  /* fix_truncdfdi2 */
    case 98:  /* fixuns_truncsfsi2 */
    case 99:  /* fixuns_truncsfdi2 */
    case 100:  /* fixuns_truncdfsi2 */
    case 101:  /* fixuns_truncdfdi2 */
    case 102:  /* floatsisf2 */
    case 103:  /* floatdisf2 */
    case 104:  /* floatsidf2 */
    case 105:  /* floatdidf2 */
    case 106:  /* floatunssisf2 */
    case 107:  /* floatunsdisf2 */
    case 108:  /* floatunssidf2 */
    case 109:  /* floatunsdidf2 */
    case 110:  /* lrintsfsi2 */
    case 111:  /* lroundsfsi2 */
    case 112:  /* lrintsfdi2 */
    case 113:  /* lroundsfdi2 */
    case 114:  /* lrintdfsi2 */
    case 115:  /* lrounddfsi2 */
    case 116:  /* lrintdfdi2 */
    case 117:  /* lrounddfdi2 */
      return TYPE_FCVT;

    case 163:  /* *cstoresfsi4 */
    case 164:  /* *cstoresfdi4 */
    case 165:  /* *cstoredfsi4 */
    case 166:  /* *cstoredfdi4 */
    case 167:  /* flt_quietsfsi4 */
    case 168:  /* fle_quietsfsi4 */
    case 169:  /* flt_quietsfdi4 */
    case 170:  /* fle_quietsfdi4 */
    case 171:  /* flt_quietdfsi4 */
    case 172:  /* fle_quietdfsi4 */
    case 173:  /* flt_quietdfdi4 */
    case 174:  /* fle_quietdfdi4 */
      return TYPE_FCMP;

    case 37:  /* divsf3 */
    case 38:  /* divdf3 */
      return TYPE_FDIV;

    case 41:  /* fmasf4 */
    case 42:  /* fmadf4 */
    case 43:  /* fmssf4 */
    case 44:  /* fmsdf4 */
    case 45:  /* fnmssf4 */
    case 46:  /* fnmsdf4 */
    case 47:  /* fnmasf4 */
    case 48:  /* fnmadf4 */
    case 49:  /* *fmasf4 */
    case 50:  /* *fmadf4 */
    case 51:  /* *fmssf4 */
    case 52:  /* *fmsdf4 */
    case 53:  /* *fnmssf4 */
    case 54:  /* *fnmsdf4 */
    case 55:  /* *fnmasf4 */
    case 56:  /* *fnmadf4 */
      return TYPE_FMADD;

    case 13:  /* mulsf3 */
    case 14:  /* muldf3 */
      return TYPE_FMUL;

    case 1:  /* addsf3 */
    case 2:  /* adddf3 */
    case 7:  /* subsf3 */
    case 8:  /* subdf3 */
      return TYPE_FADD;

    case 57:  /* abssf2 */
    case 58:  /* absdf2 */
    case 59:  /* copysignsf3 */
    case 60:  /* copysigndf3 */
    case 61:  /* negsf2 */
    case 62:  /* negdf2 */
    case 63:  /* sminsf3 */
    case 64:  /* smindf3 */
    case 65:  /* smaxsf3 */
    case 66:  /* smaxdf3 */
      return TYPE_FMOVE;

    case 25:  /* divsi3 */
    case 26:  /* udivsi3 */
    case 27:  /* modsi3 */
    case 28:  /* umodsi3 */
    case 29:  /* divdi3 */
    case 30:  /* udivdi3 */
    case 31:  /* moddi3 */
    case 32:  /* umoddi3 */
    case 33:  /* *divsi3_extended */
    case 34:  /* *udivsi3_extended */
    case 35:  /* *modsi3_extended */
    case 36:  /* *umodsi3_extended */
      return TYPE_IDIV;

    case 15:  /* mulsi3 */
    case 16:  /* muldi3 */
    case 17:  /* *mulsi3_extended */
    case 18:  /* *mulsi3_extended2 */
    case 19:  /* muldi3_highpart */
    case 20:  /* umuldi3_highpart */
    case 21:  /* usmuldi3_highpart */
    case 22:  /* mulsi3_highpart */
    case 23:  /* umulsi3_highpart */
    case 24:  /* usmulsi3_highpart */
      return TYPE_IMUL;

    case 175:  /* *seq_zero_sisi */
    case 176:  /* *seq_zero_disi */
    case 177:  /* *seq_zero_didi */
    case 178:  /* *sne_zero_sisi */
    case 179:  /* *sne_zero_disi */
    case 180:  /* *sne_zero_didi */
    case 181:  /* *sgt_sisi */
    case 182:  /* *sgtu_sisi */
    case 183:  /* *sgt_disi */
    case 184:  /* *sgtu_disi */
    case 185:  /* *sgt_didi */
    case 186:  /* *sgtu_didi */
    case 187:  /* *sge_sisi */
    case 188:  /* *sgeu_sisi */
    case 189:  /* *sge_disi */
    case 190:  /* *sgeu_disi */
    case 191:  /* *sge_didi */
    case 192:  /* *sgeu_didi */
    case 193:  /* *slt_sisi */
    case 194:  /* *sltu_sisi */
    case 195:  /* *slt_disi */
    case 196:  /* *sltu_disi */
    case 197:  /* *slt_didi */
    case 198:  /* *sltu_didi */
    case 199:  /* *sle_sisi */
    case 200:  /* *sleu_sisi */
    case 201:  /* *sle_disi */
    case 202:  /* *sleu_disi */
    case 203:  /* *sle_didi */
    case 204:  /* *sleu_didi */
      return TYPE_SLT;

    case 146:  /* ashlsi3 */
    case 147:  /* ashrsi3 */
    case 148:  /* lshrsi3 */
    case 149:  /* ashldi3 */
    case 150:  /* ashrdi3 */
    case 151:  /* lshrdi3 */
    case 152:  /* *ashlsi3_extend */
    case 153:  /* *ashrsi3_extend */
    case 154:  /* *lshrsi3_extend */
      return TYPE_SHIFT;

    case 67:  /* andsi3 */
    case 68:  /* iorsi3 */
    case 69:  /* xorsi3 */
    case 70:  /* anddi3 */
    case 71:  /* iordi3 */
    case 72:  /* xordi3 */
    case 73:  /* *andsi3_internal */
    case 74:  /* *iorsi3_internal */
    case 75:  /* *xorsi3_internal */
    case 76:  /* one_cmplsi2 */
    case 77:  /* one_cmpldi2 */
    case 78:  /* *one_cmplsi2_internal */
    case 136:  /* *xorhihi3 */
    case 137:  /* *xorsihi3 */
      return TYPE_LOGICAL;

    case 3:  /* addsi3 */
    case 4:  /* adddi3 */
    case 5:  /* *addsi3_extended */
    case 6:  /* *addsi3_extended2 */
    case 9:  /* subdi3 */
    case 10:  /* subsi3 */
    case 11:  /* *subsi3_extended */
    case 12:  /* *subsi3_extended2 */
    case 120:  /* tls_add_tp_lesi */
    case 121:  /* tls_add_tp_ledi */
    case 126:  /* auipcsi */
    case 127:  /* auipcdi */
    case 128:  /* *lowsi */
    case 129:  /* *lowdi */
    case 134:  /* *addhihi3 */
    case 135:  /* *addsihi3 */
      return TYPE_ARITH;

    case 125:  /* got_load_tls_iedi */
    case 124:  /* got_load_tls_iesi */
    case 123:  /* got_load_tls_gddi */
    case 122:  /* got_load_tls_gdsi */
    case 119:  /* got_loaddi */
    case 118:  /* got_loadsi */
      return TYPE_LOAD;

    case 215:  /* sibcall_internal */
    case 216:  /* sibcall_value_internal */
    case 217:  /* call_internal */
    case 218:  /* call_value_internal */
      return TYPE_CALL;

    case 205:  /* jump */
    case 206:  /* indirect_jumpsi */
    case 207:  /* indirect_jumpdi */
    case 208:  /* tablejumpsi */
    case 209:  /* tablejumpdi */
    case 211:  /* simple_return */
    case 212:  /* simple_return_internal */
      return TYPE_JUMP;

    case 155:  /* *branch_ordersi */
    case 156:  /* *branch_orderdi */
    case 157:  /* *branch_zerosi */
    case 158:  /* *branch_zerodi */
      return TYPE_BRANCH;

    default:
      return TYPE_UNKNOWN;

    }
}

int
eligible_for_delay (rtx_insn *delay_insn ATTRIBUTE_UNUSED, int slot, 
		   rtx_insn *candidate_insn, int flags ATTRIBUTE_UNUSED)
{
  rtx_insn *insn ATTRIBUTE_UNUSED;

  if (num_delay_slots (delay_insn) == 0)
    return 0;
  gcc_assert (slot < 0);

  if (!INSN_P (candidate_insn))
    return 0;

  insn = candidate_insn;
  switch (slot)
    {
    default:
      gcc_unreachable ();
    }
}

int
eligible_for_annul_true (rtx_insn *delay_insn ATTRIBUTE_UNUSED,
    int slot ATTRIBUTE_UNUSED,
    rtx_insn *candidate_insn ATTRIBUTE_UNUSED,
    int flags ATTRIBUTE_UNUSED)
{
  return 0;
}

int
eligible_for_annul_false (rtx_insn *delay_insn ATTRIBUTE_UNUSED,
    int slot ATTRIBUTE_UNUSED,
    rtx_insn *candidate_insn ATTRIBUTE_UNUSED,
    int flags ATTRIBUTE_UNUSED)
{
  return 0;
}

int
const_num_delay_slots (rtx_insn *insn)
{
  switch (recog_memoized (insn))
    {
    default:
      return 1;
    }
}

EXPORTED_CONST int length_unit_log = 0;
